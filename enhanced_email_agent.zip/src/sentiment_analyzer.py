"""
Sentiment Analysis module for Email Management AI Agent.
Detects emotional tone and urgency in emails.
"""

import re
import nltk
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from collections import Counter

# Download required NLTK resources
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')
    
try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords')
    
try:
    nltk.data.find('corpora/wordnet')
except LookupError:
    nltk.download('wordnet')

class SentimentAnalyzer:
    """
    Handles detection of emotional tone and urgency in emails.
    """
    
    def __init__(self):
        """
        Initialize the sentiment analyzer.
        """
        # Initialize NLP components
        self.stop_words = set(stopwords.words('english'))
        self.lemmatizer = WordNetLemmatizer()
        
        # Emotion dictionaries
        self.emotion_lexicon = {
            'frustration': [
                'frustrated', 'annoyed', 'irritated', 'upset', 'disappointed', 
                'dissatisfied', 'unhappy', 'displeased', 'bothered', 'troubled',
                'aggravated', 'agitated', 'exasperated', 'fed up', 'impatient',
                'problem', 'issue', 'concern', 'difficulty', 'challenge',
                'struggle', 'fail', 'failed', 'failure', 'mistake', 'error',
                'wrong', 'incorrect', 'not working', 'doesn\'t work', 'broken'
            ],
            'satisfaction': [
                'satisfied', 'pleased', 'happy', 'glad', 'delighted', 
                'content', 'grateful', 'thankful', 'appreciative', 'impressed',
                'excellent', 'great', 'good', 'wonderful', 'fantastic',
                'amazing', 'outstanding', 'exceptional', 'perfect', 'brilliant',
                'superb', 'terrific', 'awesome', 'impressive', 'splendid',
                'success', 'successful', 'achievement', 'accomplish', 'achieved'
            ],
            'urgency': [
                'urgent', 'immediately', 'asap', 'as soon as possible', 'right away',
                'quickly', 'promptly', 'expedite', 'rush', 'hurry', 'swift',
                'critical', 'crucial', 'vital', 'essential', 'important',
                'priority', 'time-sensitive', 'deadline', 'due', 'emergency',
                'pressing', 'imperative', 'now', 'today', 'soon',
                'cannot wait', 'can\'t wait', 'without delay', 'at once'
            ],
            'appreciation': [
                'thank', 'thanks', 'thank you', 'grateful', 'appreciate',
                'appreciation', 'thankful', 'gratitude', 'indebted', 'obliged',
                'recognition', 'acknowledged', 'valued', 'admire', 'admiration',
                'impressed', 'impressive', 'excellent', 'outstanding', 'exceptional',
                'wonderful', 'fantastic', 'great', 'good', 'helpful',
                'supportive', 'assistance', 'support', 'help', 'aided'
            ],
            'concern': [
                'concerned', 'worry', 'worried', 'anxious', 'uneasy',
                'apprehensive', 'troubled', 'disturbed', 'distressed', 'alarmed',
                'fear', 'afraid', 'scared', 'frightened', 'terrified',
                'nervous', 'tense', 'stressed', 'stress', 'pressure',
                'uncertain', 'unsure', 'doubt', 'doubtful', 'hesitant',
                'risk', 'risky', 'dangerous', 'threat', 'threatening'
            ],
            'confusion': [
                'confused', 'confusing', 'unclear', 'ambiguous', 'vague',
                'puzzled', 'perplexed', 'bewildered', 'baffled', 'lost',
                'misunderstood', 'misunderstanding', 'miscommunication', 'mistake', 'error',
                'uncertain', 'unsure', 'doubt', 'question', 'wondering',
                'clarify', 'clarification', 'explain', 'explanation', 'understand'
            ]
        }
        
        # Urgency indicators with weights
        self.urgency_indicators = {
            'immediate': [
                ('urgent', 5), ('emergency', 5), ('asap', 5), ('immediately', 5), ('right away', 5),
                ('right now', 5), ('as soon as possible', 4), ('critical', 4), ('crucial', 4),
                ('without delay', 4), ('at once', 4), ('time sensitive', 4), ('time-sensitive', 4)
            ],
            'today': [
                ('today', 3), ('by end of day', 4), ('by close of business', 4), ('cob', 4),
                ('eod', 4), ('this morning', 3), ('this afternoon', 3), ('this evening', 3),
                ('within hours', 4), ('few hours', 3), ('couple of hours', 3)
            ],
            'tomorrow': [
                ('tomorrow', 2), ('next day', 2), ('by tomorrow', 3), ('within 24 hours', 3),
                ('24 hours', 3), ('one day', 2), ('1 day', 2)
            ],
            'this_week': [
                ('this week', 1), ('within days', 2), ('few days', 1), ('couple of days', 1),
                ('by friday', 2), ('before weekend', 2), ('within 48 hours', 2), ('48 hours', 2)
            ]
        }
        
        # Passive-aggressive phrases
        self.passive_aggressive_phrases = [
            'as per my last email', 'as stated previously', 'as mentioned before',
            'as I said earlier', 'as already discussed', 'as noted above',
            'per my previous email', 'refer to my previous message', 'reattaching for convenience',
            'friendly reminder', 'just a reminder', 'gentle reminder',
            'for the second time', 'once again', 'to repeat myself',
            'circling back', 'following up again', 'checking in again',
            'not sure if you saw', 'in case you missed', 'perhaps you overlooked',
            'I thought I was clear', 'to clarify', 'to be clear',
            'going forward', 'moving forward', 'in the future',
            'please advise', 'kindly advise', 'let me know if you need anything else',
            'thanks in advance', 'I appreciate your prompt response', 'at your earliest convenience'
        ]
        
        # Stress indicators
        self.stress_indicators = [
            'overwhelmed', 'stressed', 'pressure', 'overloaded', 'swamped',
            'too much', 'excessive', 'burden', 'stressful', 'demanding',
            'difficult', 'challenging', 'hard', 'tough', 'struggling',
            'exhausted', 'tired', 'fatigue', 'burnout', 'worn out',
            'anxious', 'anxiety', 'worried', 'concern', 'fear',
            'deadline', 'time constraint', 'running out of time', 'behind schedule', 'late',
            'urgent', 'emergency', 'crisis', 'critical', 'crucial',
            'workload', 'backlog', 'pile up', 'accumulate', 'mounting'
        ]
        
        # Relationship indicators
        self.relationship_indicators = {
            'positive': [
                'thank', 'thanks', 'appreciate', 'grateful', 'helpful',
                'support', 'assist', 'collaboration', 'teamwork', 'partnership',
                'excellent', 'great', 'good', 'wonderful', 'fantastic',
                'pleasure', 'enjoy', 'delighted', 'happy', 'glad',
                'impressive', 'impressed', 'admire', 'respect', 'value'
            ],
            'negative': [
                'disappoint', 'frustrat', 'annoy', 'irritate', 'upset',
                'concern', 'worry', 'anxious', 'nervous', 'stress',
                'delay', 'late', 'miss', 'fail', 'error',
                'mistake', 'problem', 'issue', 'difficult', 'challenge',
                'disagree', 'conflict', 'dispute', 'argument', 'tension'
            ],
            'neutral': [
                'inform', 'update', 'advise', 'notify', 'tell',
                'share', 'provide', 'send', 'forward', 'attach',
                'request', 'ask', 'inquire', 'question', 'query',
                'schedule', 'arrange', 'organize', 'coordinate', 'plan',
                'discuss', 'talk', 'speak', 'conversation', 'meeting'
            ]
        }
    
    def analyze_sentiment(self, email):
        """
        Analyze sentiment in an email.
        
        Args:
            email (dict): Email data
            
        Returns:
            dict: Sentiment analysis results
        """
        # Extract email content
        subject = email.get('subject', '')
        body = email.get('body', '')
        sender = email.get('sender', '')
        
        # Combine subject and body for analysis
        text = f"{subject}\n{body}"
        
        # Preprocess text
        preprocessed_text = self._preprocess_text(text)
        
        # Detect emotions
        emotions = self._detect_emotions(preprocessed_text)
        
        # Assess urgency
        urgency = self._assess_urgency(text)
        
        # Detect passive-aggressive tone
        passive_aggressive = self._detect_passive_aggressive(text)
        
        # Detect stress indicators
        stress = self._detect_stress(text)
        
        # Determine overall sentiment
        overall_sentiment = self._determine_overall_sentiment(emotions, urgency, passive_aggressive)
        
        # Create sentiment analysis result
        sentiment_analysis = {
            'overall_sentiment': overall_sentiment,
            'emotions': emotions,
            'urgency': urgency,
            'passive_aggressive': passive_aggressive,
            'stress_indicators': stress,
            'requires_attention': self._requires_attention(emotions, urgency, passive_aggressive, stress)
        }
        
        return sentiment_analysis
    
    def _preprocess_text(self, text):
        """
        Preprocess text for sentiment analysis.
        
        Args:
            text (str): Text to preprocess
            
        Returns:
            list: Preprocessed tokens
        """
        # Tokenize text
        tokens = word_tokenize(text.lower())
        
        # Remove stopwords and punctuation
        tokens = [token for token in tokens if token.isalnum() and token not in self.stop_words]
        
        # Lemmatize tokens
        tokens = [self.lemmatizer.lemmatize(token) for token in tokens]
        
        return tokens
    
    def _detect_emotions(self, preprocessed_text):
        """
        Detect emotions in preprocessed text.
        
        Args:
            preprocessed_text (list): Preprocessed tokens
            
        Returns:
            dict: Detected emotions with scores
        """
        # Initialize emotion scores
        emotion_scores = {emotion: 0 for emotion in self.emotion_lexicon.keys()}
        
        # Count emotion words
        for token in preprocessed_text:
            for emotion, words in self.emotion_lexicon.items():
                if token in words or any(word in token for word in words):
                    emotion_scores[emotion] += 1
        
        # Normalize scores
        total_emotions = sum(emotion_scores.values())
        if total_emotions > 0:
            for emotion in emotion_scores:
                emotion_scores[emotion] = round((emotion_scores[emotion] / len(preprocessed_text)) * 100, 2)
        
        # Get primary and secondary emotions
        sorted_emotions = sorted(emotion_scores.items(), key=lambda x: x[1], reverse=True)
        primary_emotion = sorted_emotions[0][0] if sorted_emotions[0][1] > 0 else 'neutral'
        secondary_emotion = sorted_emotions[1][0] if len(sorted_emotions) > 1 and sorted_emotions[1][1] > 0 else None
        
        return {
            'primary': primary_emotion,
            'secondary': secondary_emotion,
            'scores': emotion_scores
        }
    
    def _assess_urgency(self, text):
        """
        Assess urgency level in text.
        
        Args:
            text (str): Text to analyze
            
        Returns:
            dict: Urgency assessment
        """
        # Initialize urgency score
        urgency_score = 0
        matched_indicators = []
        
        # Check for urgency indicators
        text_lower = text.lower()
        for category, indicators in self.urgency_indicators.items():
            for indicator, weight in indicators:
                if re.search(r'\b' + re.escape(indicator) + r'\b', text_lower):
                    urgency_score += weight
                    matched_indicators.append(indicator)
        
        # Determine urgency level
        if urgency_score >= 10:
            urgency_level = 'critical'
        elif urgency_score >= 6:
            urgency_level = 'high'
        elif urgency_score >= 3:
            urgency_level = 'medium'
        elif urgency_score > 0:
            urgency_level = 'low'
        else:
            urgency_level = 'none'
        
        return {
            'level': urgency_level,
            'score': urgency_score,
            'indicators': matched_indicators
        }
    
    def _detect_passive_aggressive(self, text):
        """
        Detect passive-aggressive tone in text.
        
        Args:
            text (str): Text to analyze
            
        Returns:
            dict: Passive-aggressive assessment
        """
        # Initialize passive-aggressive score
        pa_score = 0
        matched_phrases = []
        
        # Check for passive-aggressive phrases
        text_lower = text.lower()
        for phrase in self.passive_aggressive_phrases:
            if re.search(r'\b' + re.escape(phrase) + r'\b', text_lower):
                pa_score += 1
                matched_phrases.append(phrase)
        
        # Determine passive-aggressive level
        if pa_score >= 3:
            pa_level = 'high'
        elif pa_score >= 1:
            pa_level = 'medium'
        else:
            pa_level = 'none'
        
        return {
            'level': pa_level,
            'score': pa_score,
            'phrases': matched_phrases
        }
    
    def _detect_stress(self, text):
        """
        Detect stress indicators in text.
        
        Args:
            text (str): Text to analyze
            
        Returns:
            dict: Stress assessment
        """
        # Initialize stress score
        stress_score = 0
        matched_indicators = []
        
        # Check for stress indicators
        text_lower = text.lower()
        for indicator in self.stress_indicators:
            if re.search(r'\b' + re.escape(indicator) + r'\b', text_lower):
                stress_score += 1
                matched_indicators.append(indicator)
        
        # Determine stress level
        if stress_score >= 5:
            stress_level = 'high'
        elif stress_score >= 2:
            stress_level = 'medium'
        elif stress_score >= 1:
            stress_level = 'low'
        else:
            stress_level = 'none'
        
        return {
            'level': stress_level,
            'score': stress_score,
            'indicators': matched_indicators
        }
    
    def _determine_overall_sentiment(self, emotions, urgency, passive_aggressive):
        """
        Determine overall sentiment based on emotions, urgency, and passive-aggressive tone.
        
        Args:
            emotions (dict): Detected emotions
            urgency (dict): Urgency assessment
            passive_aggressive (dict): Passive-aggressive assessment
            
        Returns:
            str: Overall sentiment
        """
        # Get primary emotion
        primary_emotion = emotions['primary']
        
        # Determine sentiment based on primary emotion
        if primary_emotion == 'frustration' or primary_emotion == 'concern':
            sentiment = 'negative'
        elif primary_emotion == 'satisfaction' or primary_emotion == 'appreciation':
            sentiment = 'positive'
        elif primary_emotion == 'confusion':
            sentiment = 'neutral'
        else:
            sentiment = 'neutral'
        
        # Adjust sentiment based on urgency and passive-aggressive tone
        if urgency['level'] in ['critical', 'high'] and passive_aggressive['level'] in ['high', 'medium']:
            sentiment = 'negative'
        elif urgency['level'] in ['critical', 'high'] and sentiment == 'positive':
            sentiment = 'mixed'
        elif passive_aggressive['level'] in ['high'] and sentiment == 'positive':
            sentiment = 'mixed'
        
        return sentiment
    
    def _requires_attention(self, emotions, urgency, passive_aggressive, stress):
        """
        Determine if the email requires special attention.
        
        Args:
            emotions (dict): Detected emotions
            urgency (dict): Urgency assessment
            passive_aggressive (dict): Passive-aggressive assessment
            stress (dict): Stress assessment
            
        Returns:
            bool: True if requires attention, False otherwise
        """
        # Check if email requires attention based on various factors
        if urgency['level'] in ['critical', 'high']:
            return True
        
        if emotions['primary'] in ['frustration', 'concern'] and emotions['scores'][emotions['primary']] > 10:
            return True
        
        if passive_aggressive['level'] == 'high':
            return True
        
        if stress['level'] in ['high', 'medium']:
            return True
        
        return False
    
    def analyze_relationship(self, emails_from_sender):
        """
        Analyze relationship with a sender based on email history.
        
        Args:
            emails_from_sender (list): List of emails from the sender
            
        Returns:
            dict: Relationship analysis
        """
        # Initialize relationship metrics
        metrics = {
            'positive_count': 0,
            'negative_count': 0,
            'neutral_count': 0,
            'total_emails': len(emails_from_sender),
            'sentiment_trend': [],
            'common_topics': [],
            'response_rate': 0,
            'average_response_time': 0
        }
        
        # Analyze each email
        for email in emails_from_sender:
            # Get sentiment
            sentiment = self.analyze_sentiment(email)
            overall_sentiment = sentiment['overall_sentiment']
            
            # Count sentiments
            if overall_sentiment == 'positive':
                metrics['positive_count'] += 1
            elif overall_sentiment == 'negative':
                metrics['negative_count'] += 1
            else:
                metrics['neutral_count'] += 1
            
            # Add to sentiment trend
            metrics['sentiment_trend'].append({
                'date': email.get('date', ''),
                'sentiment': overall_sentiment
            })
        
        # Calculate sentiment ratio
        if metrics['total_emails'] > 0:
            positive_ratio = metrics['positive_count'] / metrics['total_emails']
            negative_ratio = metrics['negative_count'] / metrics['total_emails']
            neutral_ratio = metrics['neutral_count'] / metrics['total_emails']
        else:
            positive_ratio = negative_ratio = neutral_ratio = 0
        
        # Determine relationship status
        if positive_ratio > 0.6:
            relationship_status = 'positive'
        elif negative_ratio > 0.4:
            relationship_status = 'negative'
        elif neutral_ratio > 0.7:
            relationship_status = 'neutral'
        else:
            relationship_status = 'mixed'
        
        # Extract common topics (placeholder - would be more sophisticated in real implementation)
        common_topics = self._extract_common_topics(emails_from_sender)
        
        # Calculate response metrics (placeholder - would need actual response data)
        response_metrics = self._calculate_response_metrics(emails_from_sender)
        
        # Create relationship analysis result
        relationship_analysis = {
            'status': relationship_status,
            'metrics': metrics,
            'common_topics': common_topics,
            'response_metrics': response_metrics,
            'maintenance_suggestions': self._generate_relationship_suggestions(relationship_status, metrics)
        }
        
        return relationship_analysis
    
    def _extract_common_topics(self, emails):
        """
        Extract common topics from emails.
        
        Args:
            emails (list): List of emails
            
        Returns:
            list: Common topics
        """
        # This is a simplified implementation
        # A real implementation would use topic modeling techniques
        
        # Combine all email subjects
        all_subjects = ' '.join([email.get('subject', '') for email in emails])
        
        # Tokenize and preprocess
        tokens = self._preprocess_text(all_subjects)
        
        # Count word frequencies
        word_counts = Counter(tokens)
        
        # Get most common words (excluding very common words)
        common_words = [word for word, count in word_counts.most_common(10) if len(word) > 3]
        
        return common_words
    
    def _calculate_response_metrics(self, emails):
        """
        Calculate response metrics for emails.
        
        Args:
            emails (list): List of emails
            
        Returns:
            dict: Response metrics
        """
        # This is a placeholder implementation
        # A real implementation would track actual response data
        
        return {
            'response_rate': 0.8,  # Placeholder
            'average_response_time': 24,  # Placeholder: hours
            'response_quality': 'good'  # Placeholder
        }
    
    def _generate_relationship_suggestions(self, relationship_status, metrics):
        """
        Generate relationship maintenance suggestions.
        
        Args:
            relationship_status (str): Relationship status
            metrics (dict): Relationship metrics
            
        Returns:
            list: Relationship maintenance suggestions
        """
        suggestions = []
        
        if relationship_status == 'positive':
            suggestions.append("Maintain the positive relationship by continuing prompt and helpful responses.")
            suggestions.append("Consider proactive check-ins to further strengthen the relationship.")
        
        elif relationship_status == 'negative':
            suggestions.append("Address potential issues by being more responsive and attentive.")
            suggestions.append("Consider a direct conversation to resolve any underlying concerns.")
            suggestions.append("Use more positive and supportive language in future communications.")
        
        elif relationship_status == 'mixed':
            suggestions.append("Focus on consistency in communications to improve relationship stability.")
            suggestions.append("Pay attention to response times and thoroughness to build trust.")
        
        else:  # neutral
            suggestions.append("Consider adding more personalization to communications to build rapport.")
            suggestions.append("Look for opportunities to provide additional value beyond what's requested.")
        
        return suggestions
    
    def get_sentiment_summary(self, emails, time_period=None):
        """
        Generate a summary of sentiment across multiple emails.
        
        Args:
            emails (list): List of emails
            time_period (str, optional): Time period for analysis
            
        Returns:
            dict: Sentiment summary
        """
        # Filter emails by time period if specified
        if time_period:
            filtered_emails = self._filter_by_time_period(emails, time_period)
        else:
            filtered_emails = emails
        
        # Initialize counters
        total_emails = len(filtered_emails)
        sentiment_counts = {'positive': 0, 'negative': 0, 'neutral': 0, 'mixed': 0}
        urgency_counts = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0, 'none': 0}
        emotion_counts = {emotion: 0 for emotion in self.emotion_lexicon.keys()}
        attention_required = 0
        
        # Analyze each email
        for email in filtered_emails:
            sentiment = self.analyze_sentiment(email)
            
            # Count overall sentiment
            sentiment_counts[sentiment['overall_sentiment']] += 1
            
            # Count urgency levels
            urgency_counts[sentiment['urgency']['level']] += 1
            
            # Count primary emotions
            primary_emotion = sentiment['emotions']['primary']
            if primary_emotion != 'neutral':
                emotion_counts[primary_emotion] += 1
            
            # Count emails requiring attention
            if sentiment['requires_attention']:
                attention_required += 1
        
        # Calculate percentages
        if total_emails > 0:
            sentiment_percentages = {k: round((v / total_emails) * 100, 1) for k, v in sentiment_counts.items()}
            urgency_percentages = {k: round((v / total_emails) * 100, 1) for k, v in urgency_counts.items()}
            attention_percentage = round((attention_required / total_emails) * 100, 1)
        else:
            sentiment_percentages = {k: 0 for k in sentiment_counts.keys()}
            urgency_percentages = {k: 0 for k in urgency_counts.keys()}
            attention_percentage = 0
        
        # Get dominant emotions
        sorted_emotions = sorted([(emotion, count) for emotion, count in emotion_counts.items() if count > 0], 
                                key=lambda x: x[1], reverse=True)
        dominant_emotions = [emotion for emotion, count in sorted_emotions[:3]]
        
        # Create sentiment summary
        summary = {
            'total_emails': total_emails,
            'sentiment_counts': sentiment_counts,
            'sentiment_percentages': sentiment_percentages,
            'urgency_counts': urgency_counts,
            'urgency_percentages': urgency_percentages,
            'dominant_emotions': dominant_emotions,
            'attention_required': attention_required,
            'attention_percentage': attention_percentage,
            'time_period': time_period
        }
        
        return summary
    
    def _filter_by_time_period(self, emails, time_period):
        """
        Filter emails by time period.
        
        Args:
            emails (list): List of emails
            time_period (str): Time period for filtering
            
        Returns:
            list: Filtered emails
        """
        # This is a placeholder implementation
        # A real implementation would parse dates and filter accordingly
        
        return emails  # Return all emails for now
    
    def get_sender_sentiment_profile(self, sender, emails):
        """
        Generate a sentiment profile for a specific sender.
        
        Args:
            sender (str): Email sender
            emails (list): List of all emails
            
        Returns:
            dict: Sender sentiment profile
        """
        # Filter emails from this sender
        sender_emails = [email for email in emails if email.get('sender') == sender]
        
        # Get relationship analysis
        relationship = self.analyze_relationship(sender_emails)
        
        # Get sentiment summary
        sentiment_summary = self.get_sentiment_summary(sender_emails)
        
        # Create sender profile
        profile = {
            'sender': sender,
            'email_count': len(sender_emails),
            'relationship_status': relationship['status'],
            'sentiment_summary': sentiment_summary,
            'common_topics': relationship['common_topics'],
            'response_metrics': relationship['response_metrics'],
            'suggestions': relationship['maintenance_suggestions']
        }
        
        return profile
