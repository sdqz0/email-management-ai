build = "pip install -r requirements.txt"
