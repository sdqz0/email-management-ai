"""
Advanced Natural Language Understanding module for Email Management AI Agent.
Improves comprehension of complex email content to better extract meaning and requirements.
"""

import re
import nltk
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import spacy
import string
from collections import defaultdict

# Download required NLTK resources
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')
    
try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords')
    
try:
    nltk.data.find('corpora/wordnet')
except LookupError:
    nltk.download('wordnet')

# Load spaCy model
try:
    nlp = spacy.load("en_core_web_md")
except:
    # If model not found, download it
    import os
    os.system("python -m spacy download en_core_web_md")
    nlp = spacy.load("en_core_web_md")

class AdvancedNLPUnderstanding:
    """
    Handles advanced natural language understanding for complex email content.
    """
    
    def __init__(self):
        """
        Initialize the advanced NLP understanding system.
        """
        # Initialize NLP components
        self.stop_words = set(stopwords.words('english'))
        self.lemmatizer = WordNetLemmatizer()
        
        # Multi-part request patterns
        self.request_indicators = [
            r'(?:please|kindly|could you|can you|would you)\s+(.+?)[\.;,]',
            r'(?:need|want|require)\s+you\s+to\s+(.+?)[\.;,]',
            r'(?:would|should)\s+(?:like|appreciate)\s+(?:it\s+)?if\s+you\s+(?:could|would)\s+(.+?)[\.;,]',
            r'(?:I\'m|I am)\s+(?:asking|requesting)\s+(?:you\s+)?to\s+(.+?)[\.;,]',
            r'(?:hoping|hope)\s+(?:you\s+)?(?:can|could|will|would)\s+(.+?)[\.;,]'
        ]
        
        # List markers for multi-part requests
        self.list_markers = [
            r'^\s*(\d+\.|\d+\)|\*|\-|\•)\s+',  # Numbered or bullet points
            r'(?:first(?:ly)?|1st|one)[,:\s]\s*(.+?)[\.;,]',
            r'(?:second(?:ly)?|2nd|two)[,:\s]\s*(.+?)[\.;,]',
            r'(?:third(?:ly)?|3rd|three)[,:\s]\s*(.+?)[\.;,]',
            r'(?:fourth(?:ly)?|4th|four)[,:\s]\s*(.+?)[\.;,]',
            r'(?:fifth(?:ly)?|5th|five)[,:\s]\s*(.+?)[\.;,]',
            r'(?:finally|lastly|last)[,:\s]\s*(.+?)[\.;,]'
        ]
        
        # Conditional request patterns
        self.conditional_patterns = [
            r'if\s+(.+?),\s+(?:please|kindly|could you|can you|would you)\s+(.+?)[\.;,]',
            r'(?:please|kindly|could you|can you|would you)\s+(.+?)\s+if\s+(.+?)[\.;,]',
            r'(?:assuming|provided|given)\s+that\s+(.+?),\s+(.+?)[\.;,]',
            r'(?:once|after|when)\s+(.+?),\s+(?:please|kindly|could you|can you|would you)\s+(.+?)[\.;,]',
            r'(?:depending|based)\s+on\s+(.+?),\s+(.+?)[\.;,]'
        ]
        
        # Reference resolution patterns
        self.reference_patterns = {
            'pronoun': [
                r'\b(it|this|that|these|those|they|them|their)\b',
                r'\b(he|him|his|she|her|hers)\b'
            ],
            'temporal': [
                r'\b(yesterday|today|tomorrow)\b',
                r'\b(last|this|next)\s+(week|month|year|quarter)\b',
                r'\b(previous|current|upcoming)\s+(week|month|year|quarter)\b'
            ],
            'document': [
                r'\b(attached|attachment|document|file|spreadsheet|presentation)\b',
                r'\b(report|analysis|proposal|plan|draft|version)\b'
            ]
        }
        
        # Domain-specific terminology (to be expanded based on user's industry)
        self.domain_terminology = {
            'general_business': {
                'KPI': 'Key Performance Indicator',
                'ROI': 'Return on Investment',
                'EOD': 'End of Day',
                'COB': 'Close of Business',
                'EOM': 'End of Month',
                'EOY': 'End of Year',
                'OKR': 'Objectives and Key Results',
                'ASAP': 'As Soon As Possible',
                'FYI': 'For Your Information',
                'TL;DR': 'Too Long; Didn\'t Read (Summary)',
                'WFH': 'Work From Home',
                'OOO': 'Out of Office',
                'NDA': 'Non-Disclosure Agreement',
                'SOW': 'Statement of Work',
                'EOB': 'End of Business',
                'QBR': 'Quarterly Business Review'
            },
            'tech': {
                'PR': 'Pull Request',
                'LGTM': 'Looks Good To Me',
                'WIP': 'Work In Progress',
                'POC': 'Proof of Concept',
                'MVP': 'Minimum Viable Product',
                'UAT': 'User Acceptance Testing',
                'QA': 'Quality Assurance',
                'CI/CD': 'Continuous Integration/Continuous Deployment',
                'API': 'Application Programming Interface',
                'UI/UX': 'User Interface/User Experience',
                'SLA': 'Service Level Agreement',
                'TOS': 'Terms of Service'
            },
            'finance': {
                'P&L': 'Profit and Loss',
                'EBITDA': 'Earnings Before Interest, Taxes, Depreciation, and Amortization',
                'YOY': 'Year Over Year',
                'QOQ': 'Quarter Over Quarter',
                'MOM': 'Month Over Month',
                'AR': 'Accounts Receivable',
                'AP': 'Accounts Payable',
                'CAPEX': 'Capital Expenditure',
                'OPEX': 'Operational Expenditure',
                'FCF': 'Free Cash Flow'
            },
            'marketing': {
                'CTR': 'Click-Through Rate',
                'CPC': 'Cost Per Click',
                'CPM': 'Cost Per Mille (Cost Per Thousand Impressions)',
                'CTA': 'Call To Action',
                'SEO': 'Search Engine Optimization',
                'SEM': 'Search Engine Marketing',
                'PPC': 'Pay Per Click',
                'CR': 'Conversion Rate',
                'USP': 'Unique Selling Proposition',
                'KOL': 'Key Opinion Leader'
            }
        }
        
        # Organizational acronyms (to be populated from user data)
        self.org_acronyms = {}
        
        # Context window for reference resolution
        self.context_window = []
        self.max_context_size = 5  # Maximum number of emails in context window
    
    def analyze_email(self, email, thread_context=None):
        """
        Analyze email content with advanced NLP understanding.
        
        Args:
            email (dict): Email data
            thread_context (list, optional): Previous emails in the thread
            
        Returns:
            dict: Analysis results
        """
        # Extract email content
        subject = email.get('subject', '')
        body = email.get('body', '')
        sender = email.get('sender', '')
        
        # Update context window
        self._update_context_window(email, thread_context)
        
        # Process email with spaCy
        doc = nlp(f"{subject}\n\n{body}")
        
        # Extract multi-part requests
        requests = self._extract_requests(body, doc)
        
        # Extract conditions and dependencies
        conditions = self._extract_conditions(body, doc)
        
        # Resolve references
        resolved_references = self._resolve_references(body, doc)
        
        # Identify domain-specific terminology
        terminology = self._identify_terminology(body)
        
        # Extract entities
        entities = self._extract_entities(doc)
        
        # Analyze syntactic complexity
        complexity = self._analyze_complexity(doc)
        
        # Create analysis result
        analysis = {
            'requests': requests,
            'conditions': conditions,
            'resolved_references': resolved_references,
            'terminology': terminology,
            'entities': entities,
            'complexity': complexity,
            'summary': self._generate_summary(requests, conditions, resolved_references, terminology, entities, complexity)
        }
        
        return analysis
    
    def _update_context_window(self, email, thread_context=None):
        """
        Update context window with current email and thread context.
        
        Args:
            email (dict): Current email
            thread_context (list, optional): Previous emails in the thread
        """
        # Add current email to context window
        self.context_window.append(email)
        
        # Add thread context if provided
        if thread_context:
            for context_email in thread_context:
                if context_email not in self.context_window:
                    self.context_window.append(context_email)
        
        # Limit context window size
        if len(self.context_window) > self.max_context_size:
            self.context_window = self.context_window[-self.max_context_size:]
    
    def _extract_requests(self, text, doc):
        """
        Extract requests from email text.
        
        Args:
            text (str): Email text
            doc (spacy.Doc): Processed spaCy document
            
        Returns:
            list: Extracted requests
        """
        requests = []
        
        # Extract explicit requests using patterns
        for pattern in self.request_indicators:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                request_text = match.group(1).strip()
                if request_text and len(request_text) > 5:  # Minimum length to filter out noise
                    requests.append({
                        'text': request_text,
                        'type': 'explicit',
                        'confidence': 0.9
                    })
        
        # Extract list-based requests
        list_items = self._extract_list_items(text)
        for item in list_items:
            # Check if item looks like a request
            if any(re.search(pattern, item, re.IGNORECASE) for pattern in self.request_indicators):
                requests.append({
                    'text': item,
                    'type': 'list_item',
                    'confidence': 0.8
                })
            elif any(verb in item.lower() for verb in ['send', 'review', 'update', 'create', 'check', 'prepare', 'provide']):
                requests.append({
                    'text': item,
                    'type': 'implied',
                    'confidence': 0.7
                })
        
        # Extract implicit requests using spaCy
        for sent in doc.sents:
            # Check if sentence contains imperative verbs
            if self._is_imperative(sent) and sent.text not in [r['text'] for r in requests]:
                requests.append({
                    'text': sent.text,
                    'type': 'imperative',
                    'confidence': 0.6
                })
        
        # Deduplicate requests
        unique_requests = []
        seen_texts = set()
        
        for request in requests:
            # Normalize text for comparison
            normalized = ' '.join(request['text'].lower().split())
            
            # Check if similar request already exists
            if not any(self._is_similar_text(normalized, seen) for seen in seen_texts):
                unique_requests.append(request)
                seen_texts.add(normalized)
        
        return unique_requests
    
    def _extract_list_items(self, text):
        """
        Extract list items from text.
        
        Args:
            text (str): Text to analyze
            
        Returns:
            list: Extracted list items
        """
        list_items = []
        
        # Split text into lines
        lines = text.split('\n')
        
        # Extract numbered and bulleted list items
        for line in lines:
            line = line.strip()
            if re.match(r'^\s*(\d+\.|\d+\)|\*|\-|\•)\s+', line):
                # Remove the list marker
                item = re.sub(r'^\s*(\d+\.|\d+\)|\*|\-|\•)\s+', '', line)
                list_items.append(item)
        
        # Extract sequential markers (first, second, etc.)
        for pattern in self.list_markers[1:]:  # Skip the first pattern which is for bullet points
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                item = match.group(1).strip() if len(match.groups()) > 0 else match.group(0).strip()
                list_items.append(item)
        
        return list_items
    
    def _is_imperative(self, sent):
        """
        Check if a sentence is in imperative form.
        
        Args:
            sent (spacy.Span): Sentence to check
            
        Returns:
            bool: True if imperative, False otherwise
        """
        # Imperative sentences often start with a verb
        if len(sent) > 0 and sent[0].pos_ == 'VERB':
            return True
        
        # Or they might start with 'Please' followed by a verb
        if len(sent) > 1 and sent[0].text.lower() == 'please' and sent[1].pos_ == 'VERB':
            return True
        
        # Check for other imperative indicators
        imperative_starters = ['kindly', 'please', 'ensure', 'make sure', 'remember']
        if any(sent.text.lower().startswith(starter) for starter in imperative_starters):
            return True
        
        return False
    
    def _is_similar_text(self, text1, text2, threshold=0.7):
        """
        Check if two texts are similar.
        
        Args:
            text1 (str): First text
            text2 (str): Second text
            threshold (float): Similarity threshold
            
        Returns:
            bool: True if similar, False otherwise
        """
        # Simple Jaccard similarity
        set1 = set(text1.split())
        set2 = set(text2.split())
        
        intersection = len(set1.intersection(set2))
        union = len(set1.union(set2))
        
        if union == 0:
            return False
        
        similarity = intersection / union
        return similarity >= threshold
    
    def _extract_conditions(self, text, doc):
        """
        Extract conditions and dependencies from text.
        
        Args:
            text (str): Email text
            doc (spacy.Doc): Processed spaCy document
            
        Returns:
            list: Extracted conditions
        """
        conditions = []
        
        # Extract explicit conditions using patterns
        for pattern in self.conditional_patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                if len(match.groups()) >= 2:
                    condition_text = match.group(1).strip()
                    action_text = match.group(2).strip()
                    
                    conditions.append({
                        'condition': condition_text,
                        'action': action_text,
                        'type': 'explicit',
                        'confidence': 0.9
                    })
        
        # Extract implicit conditions using spaCy
        for sent in doc.sents:
            # Look for conditional markers
            if any(token.text.lower() in ['if', 'when', 'once', 'after', 'before', 'unless', 'until'] for token in sent):
                # Skip if already captured by explicit patterns
                if not any(cond['condition'] in sent.text and cond['action'] in sent.text for cond in conditions):
                    # Try to split into condition and action
                    condition_parts = self._split_conditional(sent.text)
                    if condition_parts:
                        conditions.append({
                            'condition': condition_parts[0],
                            'action': condition_parts[1],
                            'type': 'implicit',
                            'confidence': 0.7
                        })
        
        return conditions
    
    def _split_conditional(self, text):
        """
        Split a conditional sentence into condition and action parts.
        
        Args:
            text (str): Sentence to split
            
        Returns:
            tuple: (condition, action) or None if not splittable
        """
        # Common conditional markers
        markers = ['if', 'when', 'once', 'after', 'before', 'unless', 'until']
        
        # Try to split on each marker
        for marker in markers:
            pattern = r'\b' + re.escape(marker) + r'\b'
            match = re.search(pattern, text, re.IGNORECASE)
            
            if match:
                # Split on the marker
                parts = re.split(pattern, text, maxsplit=1, flags=re.IGNORECASE)
                
                if len(parts) == 2:
                    # If marker is at the beginning
                    if not parts[0].strip():
                        # Find the next comma or conjunction
                        action_start = re.search(r'[,;]|\b(then|please|kindly)\b', parts[1])
                        if action_start:
                            idx = action_start.start()
                            condition = marker + ' ' + parts[1][:idx].strip()
                            action = parts[1][idx+1:].strip()
                            return (condition, action)
                    else:
                        # If marker is in the middle
                        condition = marker + ' ' + parts[1].strip()
                        action = parts[0].strip()
                        return (condition, action)
        
        # Try to split on comma followed by conditional marker
        for marker in markers:
            pattern = r',\s*' + re.escape(marker) + r'\b'
            match = re.search(pattern, text, re.IGNORECASE)
            
            if match:
                # Split on the pattern
                parts = re.split(pattern, text, maxsplit=1, flags=re.IGNORECASE)
                
                if len(parts) == 2:
                    action = parts[0].strip()
                    condition = marker + ' ' + parts[1].strip()
                    return (condition, action)
        
        return None
    
    def _resolve_references(self, text, doc):
        """
        Resolve references in text.
        
        Args:
            text (str): Email text
            doc (spacy.Doc): Processed spaCy document
            
        Returns:
            dict: Resolved references
        """
        resolved_references = {
            'pronouns': [],
            'temporal': [],
            'document': []
        }
        
        # Resolve pronouns
        for sent in doc.sents:
            for token in sent:
                if token.pos_ == 'PRON' and token.text.lower() in ['it', 'this', 'that', 'these', 'those', 'they', 'them', 'their', 'he', 'him', 'his', 'she', 'her', 'hers']:
                    # Get the reference
                    reference = self._resolve_pronoun(token, sent, doc)
                    if reference:
                        resolved_references['pronouns'].append({
                            'pronoun': token.text,
                            'reference': reference,
                            'context': sent.text,
                            'confidence': 0.7
                        })
        
        # Resolve temporal references
        for pattern in self.reference_patterns['temporal']:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                temporal_ref = match.group(0)
                resolved = self._resolve_temporal(temporal_ref)
                if resolved:
                    resolved_references['temporal'].append({
                        'reference': temporal_ref,
                        'resolved': resolved,
                        'confidence': 0.8
                    })
        
        # Resolve document references
        for pattern in self.reference_patterns['document']:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                doc_ref = match.group(0)
                context = self._get_context_around_match(text, match)
                resolved = self._resolve_document(doc_ref, context)
                if resolved:
                    resolved_references['document'].append({
                        'reference': doc_ref,
                        'context': context,
                        'resolved': resolved,
                        'confidence': 0.6
                    })
        
        return resolved_references
    
    def _resolve_pronoun(self, pronoun, sentence, doc):
        """
        Resolve a pronoun to its referent.
        
        Args:
            pronoun (spacy.Token): Pronoun token
            sentence (spacy.Span): Sentence containing the pronoun
            doc (spacy.Doc): Full document
            
        Returns:
            str: Resolved reference or None
        """
        # This is a simplified implementation
        # A real implementation would use coreference resolution
        
        # Get previous sentences
        sent_start = sentence.start
        prev_sentences = []
        for sent in doc.sents:
            if sent.start < sent_start:
                prev_sentences.append(sent)
        
        # Reverse to start from the closest sentence
        prev_sentences.reverse()
        
        # Look for potential referents in previous sentences
        if pronoun.text.lower() in ['it', 'this', 'that']:
            # Look for the closest noun phrase
            for sent in prev_sentences:
                for chunk in sent.noun_chunks:
                    if chunk.root.pos_ in ['NOUN', 'PROPN']:
                        return chunk.text
        
        elif pronoun.text.lower() in ['they', 'them', 'their', 'these', 'those']:
            # Look for plural nouns or multiple entities
            for sent in prev_sentences:
                plural_nouns = [chunk for chunk in sent.noun_chunks if chunk.root.tag_ == 'NNS']
                if plural_nouns:
                    return plural_nouns[0].text
        
        elif pronoun.text.lower() in ['he', 'him', 'his']:
            # Look for male entities
            for sent in prev_sentences:
                for ent in sent.ents:
                    if ent.label_ == 'PERSON':
                        # This is a simplification; would need gender detection in a real implementation
                        return ent.text
        
        elif pronoun.text.lower() in ['she', 'her', 'hers']:
            # Look for female entities
            for sent in prev_sentences:
                for ent in sent.ents:
                    if ent.label_ == 'PERSON':
                        # This is a simplification; would need gender detection in a real implementation
                        return ent.text
        
        # If no referent found in previous sentences, check context window
        if self.context_window:
            for context_email in reversed(self.context_window[:-1]):  # Skip current email
                context_subject = context_email.get('subject', '')
                context_sender = context_email.get('sender', '')
                
                if pronoun.text.lower() in ['it', 'this', 'that']:
                    return f"Previous email subject: {context_subject}"
                
                elif pronoun.text.lower() in ['they', 'them', 'their', 'these', 'those']:
                    return "Previous discussion participants"
                
                elif pronoun.text.lower() in ['he', 'him', 'his', 'she', 'her', 'hers']:
                    return f"Previous email sender: {context_sender}"
        
        return None
    
    def _resolve_temporal(self, temporal_ref):
        """
        Resolve a temporal reference.
        
        Args:
            temporal_ref (str): Temporal reference
            
        Returns:
            str: Resolved date or None
        """
        # This is a simplified implementation
        # A real implementation would calculate actual dates
        
        import datetime
        
        today = datetime.datetime.now().date()
        
        if 'yesterday' in temporal_ref.lower():
            yesterday = today - datetime.timedelta(days=1)
            return yesterday.strftime('%Y-%m-%d')
        
        elif 'today' in temporal_ref.lower():
            return today.strftime('%Y-%m-%d')
        
        elif 'tomorrow' in temporal_ref.lower():
            tomorrow = today + datetime.timedelta(days=1)
            return tomorrow.strftime('%Y-%m-%d')
        
        elif 'last week' in temporal_ref.lower():
            last_week = today - datetime.timedelta(days=7)
            return f"Week of {last_week.strftime('%Y-%m-%d')}"
        
        elif 'this week' in temporal_ref.lower():
            return f"Week of {today.strftime('%Y-%m-%d')}"
        
        elif 'next week' in temporal_ref.lower():
            next_week = today + datetime.timedelta(days=7)
            return f"Week of {next_week.strftime('%Y-%m-%d')}"
        
        elif 'last month' in temporal_ref.lower():
            last_month = today.replace(day=1) - datetime.timedelta(days=1)
            return last_month.strftime('%Y-%m')
        
        elif 'this month' in temporal_ref.lower():
            return today.strftime('%Y-%m')
        
        elif 'next month' in temporal_ref.lower():
            if today.month == 12:
                next_month = today.replace(year=today.year+1, month=1)
            else:
                next_month = today.replace(month=today.month+1)
            return next_month.strftime('%Y-%m')
        
        return None
    
    def _resolve_document(self, doc_ref, context):
        """
        Resolve a document reference.
        
        Args:
            doc_ref (str): Document reference
            context (str): Context around the reference
            
        Returns:
            str: Resolved document or None
        """
        # Look for attachment indicators
        attachment_indicators = ['attached', 'attachment', 'enclosed', 'herewith', 'file']
        
        if any(indicator in context.lower() for indicator in attachment_indicators):
            # Check context window for attachments
            if self.context_window:
                current_email = self.context_window[-1]
                attachments = current_email.get('attachments', [])
                
                if attachments:
                    # Try to find a matching attachment
                    doc_type = doc_ref.lower()
                    for attachment in attachments:
                        attachment_name = attachment.get('name', '').lower()
                        
                        if doc_type in attachment_name:
                            return attachment.get('name')
                    
                    # If no specific match, return the first attachment
                    return attachments[0].get('name')
        
        # Look for references to previous emails
        previous_indicators = ['previous', 'earlier', 'last', 'prior']
        
        if any(indicator in context.lower() for indicator in previous_indicators):
            # Check context window for previous emails
            if len(self.context_window) > 1:
                prev_email = self.context_window[-2]
                return f"Previous email: {prev_email.get('subject', '')}"
        
        return None
    
    def _get_context_around_match(self, text, match, context_size=100):
        """
        Get context around a regex match.
        
        Args:
            text (str): Full text
            match (re.Match): Regex match object
            context_size (int): Number of characters to include before and after
            
        Returns:
            str: Context text
        """
        start = max(0, match.start() - context_size)
        end = min(len(text), match.end() + context_size)
        
        return text[start:end]
    
    def _identify_terminology(self, text):
        """
        Identify domain-specific terminology in text.
        
        Args:
            text (str): Text to analyze
            
        Returns:
            list: Identified terminology
        """
        terminology = []
        
        # Check for general business terminology
        for acronym, meaning in self.domain_terminology['general_business'].items():
            if re.search(r'\b' + re.escape(acronym) + r'\b', text, re.IGNORECASE):
                terminology.append({
                    'term': acronym,
                    'meaning': meaning,
                    'domain': 'general_business'
                })
        
        # Check for tech terminology
        for acronym, meaning in self.domain_terminology['tech'].items():
            if re.search(r'\b' + re.escape(acronym) + r'\b', text, re.IGNORECASE):
                terminology.append({
                    'term': acronym,
                    'meaning': meaning,
                    'domain': 'tech'
                })
        
        # Check for finance terminology
        for acronym, meaning in self.domain_terminology['finance'].items():
            if re.search(r'\b' + re.escape(acronym) + r'\b', text, re.IGNORECASE):
                terminology.append({
                    'term': acronym,
                    'meaning': meaning,
                    'domain': 'finance'
                })
        
        # Check for marketing terminology
        for acronym, meaning in self.domain_terminology['marketing'].items():
            if re.search(r'\b' + re.escape(acronym) + r'\b', text, re.IGNORECASE):
                terminology.append({
                    'term': acronym,
                    'meaning': meaning,
                    'domain': 'marketing'
                })
        
        # Check for organizational acronyms
        for acronym, meaning in self.org_acronyms.items():
            if re.search(r'\b' + re.escape(acronym) + r'\b', text, re.IGNORECASE):
                terminology.append({
                    'term': acronym,
                    'meaning': meaning,
                    'domain': 'organization'
                })
        
        return terminology
    
    def _extract_entities(self, doc):
        """
        Extract entities from a spaCy document.
        
        Args:
            doc (spacy.Doc): Processed spaCy document
            
        Returns:
            dict: Extracted entities by type
        """
        entities = defaultdict(list)
        
        for ent in doc.ents:
            entities[ent.label_].append({
                'text': ent.text,
                'start': ent.start_char,
                'end': ent.end_char
            })
        
        # Convert defaultdict to regular dict
        return dict(entities)
    
    def _analyze_complexity(self, doc):
        """
        Analyze syntactic complexity of text.
        
        Args:
            doc (spacy.Doc): Processed spaCy document
            
        Returns:
            dict: Complexity metrics
        """
        # Count sentences
        sentences = list(doc.sents)
        num_sentences = len(sentences)
        
        # Count tokens
        num_tokens = len(doc)
        
        # Calculate average sentence length
        avg_sentence_length = num_tokens / num_sentences if num_sentences > 0 else 0
        
        # Count complex sentences (those with multiple clauses)
        complex_sentences = 0
        for sent in sentences:
            # Count clauses by looking for verbs
            verbs = [token for token in sent if token.pos_ == 'VERB']
            if len(verbs) > 1:
                complex_sentences += 1
        
        # Calculate percentage of complex sentences
        complex_percentage = (complex_sentences / num_sentences * 100) if num_sentences > 0 else 0
        
        # Determine complexity level
        if avg_sentence_length > 25 or complex_percentage > 50:
            complexity_level = 'high'
        elif avg_sentence_length > 15 or complex_percentage > 30:
            complexity_level = 'medium'
        else:
            complexity_level = 'low'
        
        return {
            'num_sentences': num_sentences,
            'num_tokens': num_tokens,
            'avg_sentence_length': round(avg_sentence_length, 1),
            'complex_sentences': complex_sentences,
            'complex_percentage': round(complex_percentage, 1),
            'complexity_level': complexity_level
        }
    
    def _generate_summary(self, requests, conditions, references, terminology, entities, complexity):
        """
        Generate a summary of the analysis.
        
        Args:
            requests (list): Extracted requests
            conditions (list): Extracted conditions
            references (dict): Resolved references
            terminology (list): Identified terminology
            entities (dict): Extracted entities
            complexity (dict): Complexity metrics
            
        Returns:
            dict: Summary of analysis
        """
        # Count requests by type
        request_counts = defaultdict(int)
        for request in requests:
            request_counts[request['type']] += 1
        
        # Count conditions
        condition_count = len(conditions)
        
        # Count unresolved references
        unresolved_count = 0
        for ref_type, refs in references.items():
            for ref in refs:
                if not ref.get('resolved') and not ref.get('reference'):
                    unresolved_count += 1
        
        # Count terminology by domain
        terminology_counts = defaultdict(int)
        for term in terminology:
            terminology_counts[term['domain']] += 1
        
        # Count entities by type
        entity_counts = {ent_type: len(ents) for ent_type, ents in entities.items()}
        
        # Determine primary domain based on terminology
        primary_domain = max(terminology_counts.items(), key=lambda x: x[1])[0] if terminology_counts else 'general'
        
        # Determine if email needs clarification
        needs_clarification = (unresolved_count > 2 or 
                              (condition_count > 0 and len(requests) > 2) or 
                              complexity['complexity_level'] == 'high')
        
        # Create summary
        summary = {
            'request_count': len(requests),
            'request_types': dict(request_counts),
            'condition_count': condition_count,
            'unresolved_references': unresolved_count,
            'primary_domain': primary_domain,
            'complexity_level': complexity['complexity_level'],
            'needs_clarification': needs_clarification,
            'key_entities': self._extract_key_entities(entities)
        }
        
        return summary
    
    def _extract_key_entities(self, entities):
        """
        Extract key entities from entity dictionary.
        
        Args:
            entities (dict): Extracted entities by type
            
        Returns:
            dict: Key entities by type
        """
        key_entities = {}
        
        # Priority entity types
        priority_types = ['PERSON', 'ORG', 'DATE', 'TIME', 'MONEY', 'PRODUCT', 'EVENT']
        
        for entity_type in priority_types:
            if entity_type in entities and entities[entity_type]:
                # Take up to 3 entities of each type
                key_entities[entity_type] = [entity['text'] for entity in entities[entity_type][:3]]
        
        return key_entities
    
    def update_domain_terminology(self, domain, terminology_dict):
        """
        Update domain-specific terminology.
        
        Args:
            domain (str): Domain name
            terminology_dict (dict): Dictionary of terms and meanings
            
        Returns:
            bool: Success indicator
        """
        if domain in self.domain_terminology:
            self.domain_terminology[domain].update(terminology_dict)
        else:
            self.domain_terminology[domain] = terminology_dict
        
        return True
    
    def update_org_acronyms(self, acronyms_dict):
        """
        Update organizational acronyms.
        
        Args:
            acronyms_dict (dict): Dictionary of acronyms and meanings
            
        Returns:
            bool: Success indicator
        """
        self.org_acronyms.update(acronyms_dict)
        return True
    
    def get_structured_content(self, email, thread_context=None):
        """
        Get structured content from an email.
        
        Args:
            email (dict): Email data
            thread_context (list, optional): Previous emails in the thread
            
        Returns:
            dict: Structured content
        """
        # Analyze email
        analysis = self.analyze_email(email, thread_context)
        
        # Extract subject and body
        subject = email.get('subject', '')
        body = email.get('body', '')
        
        # Process with spaCy
        doc = nlp(f"{subject}\n\n{body}")
        
        # Extract key components
        requests = analysis['requests']
        conditions = analysis['conditions']
        entities = analysis['entities']
        
        # Create structured content
        structured_content = {
            'subject': subject,
            'main_topic': self._extract_main_topic(subject, body, doc),
            'action_items': self._extract_action_items(requests, conditions),
            'key_points': self._extract_key_points(doc),
            'entities': self._extract_key_entities(entities),
            'questions': self._extract_questions(body, doc),
            'deadlines': self._extract_deadlines(body, doc),
            'complexity': analysis['complexity']['complexity_level']
        }
        
        return structured_content
    
    def _extract_main_topic(self, subject, body, doc):
        """
        Extract the main topic from email.
        
        Args:
            subject (str): Email subject
            body (str): Email body
            doc (spacy.Doc): Processed spaCy document
            
        Returns:
            str: Main topic
        """
        # If subject is available, use it as the primary source
        if subject:
            # Clean subject (remove prefixes like Re:, Fwd:, etc.)
            clean_subject = re.sub(r'^(?:Re|Fwd|FW|RE|FWD):\s*', '', subject)
            return clean_subject
        
        # If no subject, try to extract from the first sentence
        sentences = list(doc.sents)
        if sentences:
            first_sent = sentences[0]
            
            # Extract noun phrases from first sentence
            noun_phrases = list(first_sent.noun_chunks)
            if noun_phrases:
                return noun_phrases[0].text
            
            # If no noun phrases, return the first sentence (truncated if too long)
            if len(first_sent.text) > 50:
                return first_sent.text[:50] + '...'
            return first_sent.text
        
        # Fallback
        return "Untitled topic"
    
    def _extract_action_items(self, requests, conditions):
        """
        Extract action items from requests and conditions.
        
        Args:
            requests (list): Extracted requests
            conditions (list): Extracted conditions
            
        Returns:
            list: Action items
        """
        action_items = []
        
        # Add requests as action items
        for request in requests:
            confidence = request.get('confidence', 0)
            if confidence >= 0.6:  # Only include reasonably confident requests
                action_items.append({
                    'text': request['text'],
                    'type': 'request',
                    'conditional': False
                })
        
        # Add conditional actions
        for condition in conditions:
            action_items.append({
                'text': condition['action'],
                'type': 'conditional',
                'conditional': True,
                'condition': condition['condition']
            })
        
        return action_items
    
    def _extract_key_points(self, doc):
        """
        Extract key points from document.
        
        Args:
            doc (spacy.Doc): Processed spaCy document
            
        Returns:
            list: Key points
        """
        key_points = []
        
        # Get all sentences
        sentences = list(doc.sents)
        
        # Skip very short sentences
        valid_sentences = [sent for sent in sentences if len(sent) > 5]
        
        # If too many sentences, focus on those with important entities or keywords
        if len(valid_sentences) > 5:
            important_sentences = []
            
            for sent in valid_sentences:
                # Check for entities
                has_entities = any(ent.label_ in ['PERSON', 'ORG', 'DATE', 'TIME', 'MONEY', 'PRODUCT', 'EVENT'] for ent in sent.ents)
                
                # Check for important keywords
                important_keywords = ['important', 'critical', 'crucial', 'significant', 'key', 'main', 'primary', 'essential', 'note', 'remember']
                has_keywords = any(token.text.lower() in important_keywords for token in sent)
                
                if has_entities or has_keywords:
                    important_sentences.append(sent)
            
            # If we found important sentences, use them; otherwise use the first few sentences
            if important_sentences:
                valid_sentences = important_sentences
            else:
                valid_sentences = valid_sentences[:5]
        
        # Extract key points from valid sentences
        for sent in valid_sentences:
            key_points.append(sent.text)
        
        return key_points
    
    def _extract_questions(self, body, doc):
        """
        Extract questions from email.
        
        Args:
            body (str): Email body
            doc (spacy.Doc): Processed spaCy document
            
        Returns:
            list: Questions
        """
        questions = []
        
        # Extract questions using regex
        question_pattern = r'[^.!?]*\?'
        matches = re.finditer(question_pattern, body)
        
        for match in matches:
            question = match.group(0).strip()
            if question and len(question) > 5:
                questions.append(question)
        
        # Extract implied questions (sentences with question words but no question mark)
        for sent in doc.sents:
            if '?' not in sent.text:
                # Check for question words at the beginning
                first_token = sent[0].text.lower() if len(sent) > 0 else ''
                if first_token in ['what', 'when', 'where', 'who', 'whom', 'whose', 'which', 'why', 'how']:
                    if sent.text not in questions:
                        questions.append(sent.text)
                
                # Check for "could you" or "can you" patterns
                if re.search(r'\b(?:could|can|would|will)\s+you\b', sent.text, re.IGNORECASE):
                    if sent.text not in questions:
                        questions.append(sent.text)
        
        return questions
    
    def _extract_deadlines(self, body, doc):
        """
        Extract deadlines from email.
        
        Args:
            body (str): Email body
            doc (spacy.Doc): Processed spaCy document
            
        Returns:
            list: Deadlines
        """
        deadlines = []
        
        # Deadline indicators
        deadline_indicators = [
            r'(?:due|deadline|complete|finish|submit|deliver)\s+by\s+(.*?)[\.;,]',
            r'(?:due|deadline|completion)\s+date(?:\s+is)?:\s+(.*?)[\.;,]',
            r'(?:needed|required)\s+by\s+(.*?)[\.;,]',
            r'by\s+(?:the\s+)?end\s+of\s+(today|tomorrow|this\s+week|next\s+week|this\s+month)',
            r'by\s+(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2}(?:st|nd|rd|th)?(?:,?\s+\d{4})?',
            r'by\s+(\d{1,2}(?:st|nd|rd|th)?\s+(?:of\s+)?(?:January|February|March|April|May|June|July|August|September|October|November|December)(?:,?\s+\d{4})?)'
        ]
        
        # Extract deadlines using regex
        for pattern in deadline_indicators:
            matches = re.finditer(pattern, body, re.IGNORECASE)
            for match in matches:
                if len(match.groups()) > 0:
                    deadline_text = match.group(1).strip()
                    context = self._get_context_around_match(body, match)
                    
                    deadlines.append({
                        'text': deadline_text,
                        'context': context
                    })
        
        # Extract dates from entities
        for ent in doc.ents:
            if ent.label_ == 'DATE' or ent.label_ == 'TIME':
                # Check if this date is in context of a deadline
                context_start = max(0, ent.start_char - 50)
                context_end = min(len(body), ent.end_char + 50)
                context = body[context_start:context_end]
                
                deadline_words = ['due', 'deadline', 'by', 'complete', 'finish', 'submit', 'deliver', 'needed', 'required']
                
                if any(word in context.lower() for word in deadline_words):
                    if not any(ent.text in d['text'] for d in deadlines):
                        deadlines.append({
                            'text': ent.text,
                            'context': context
                        })
        
        return deadlines
