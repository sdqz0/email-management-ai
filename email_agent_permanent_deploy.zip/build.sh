#!/bin/bash
# This script installs the required Python packages for the Email Management AI Agent

echo "Installing required Python packages..."
pip install -r requirements.txt

echo "Downloading NLTK data..."
python -c "import nltk; nltk.download('punkt'); nltk.download('stopwords'); nltk.download('wordnet')"

echo "Downloading spaCy models..."
python -m spacy download en_core_web_sm
python -m spacy download en_core_web_md

echo "Setup complete!"
