"""
Main application file for the Email Management AI Agent.
"""

import os
import json
import datetime
from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from werkzeug.utils import secure_filename

# Import email management modules
from email_retriever import EmailRetriever
from email_categorizer import EmailCategorizer
from email_summarizer import EmailSummarizer
from action_detector import ActionDetector
from digest_generator import DigestGenerator

# Import enhanced AI modules
from smart_response import SmartResponseGenerator
from workload_manager import WorkloadManager
from sentiment_analyzer import SentimentAnalyzer
from contextual_learning import ContextualLearningSystem
from advanced_nlp import AdvancedNLPUnderstanding
from proactive_notifications import ProactiveNotificationSystem

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.urandom(24)
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static/uploads')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload size

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Initialize components
email_retriever = None
email_categorizer = EmailCategorizer()
email_summarizer = EmailSummarizer()
action_detector = ActionDetector()
digest_generator = DigestGenerator()

# Initialize enhanced AI components
smart_response = SmartResponseGenerator()
workload_manager = WorkloadManager()
sentiment_analyzer = SentimentAnalyzer()
contextual_learning = None
advanced_nlp = AdvancedNLPUnderstanding()
proactive_notifications = None

# Demo data for development/demo purposes
DEMO_MODE = True
demo_emails = []

def load_demo_data():
    """Load demo email data."""
    global demo_emails
    
    # Create demo data directory
    demo_data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static/demo_data')
    os.makedirs(demo_data_dir, exist_ok=True)
    
    # Demo email data file
    demo_data_file = os.path.join(demo_data_dir, 'demo_emails.json')
    
    # If demo data exists, load it
    if os.path.exists(demo_data_file):
        with open(demo_data_file, 'r') as f:
            demo_emails = json.load(f)
    else:
        # Create sample demo emails
        now = datetime.datetime.now()
        yesterday = now - datetime.timedelta(days=1)
        last_week = now - datetime.timedelta(days=7)
        
        demo_emails = [
            {
                'id': 'email1',
                'sender': 'boss@example.com',
                'recipient': 'user@example.com',
                'subject': 'Urgent: Project Deadline',
                'body': """
                Hi Team,
                
                I need the project report by tomorrow. This is very urgent as the client is waiting for it.
                
                Please make sure to include:
                1. Executive summary
                2. Key findings
                3. Recommendations
                
                Let me know if you have any questions.
                
                Thanks,
                Boss
                """,
                'date': now.isoformat(),
                'read': False,
                'category': 'inbox',
                'priority': 'high',
                'attachments': []
            },
            {
                'id': 'email2',
                'sender': 'colleague@example.com',
                'recipient': 'user@example.com',
                'subject': 'Meeting Notes from Yesterday',
                'body': """
                Hi,
                
                Attached are the notes from yesterday's meeting. We discussed the following:
                
                - Project timeline updates
                - Budget allocation
                - Resource planning
                
                Please review and let me know if I missed anything.
                
                Best,
                Colleague
                """,
                'date': yesterday.isoformat(),
                'read': True,
                'category': 'inbox',
                'priority': 'medium',
                'attachments': [
                    {'name': 'meeting_notes.pdf', 'type': 'application/pdf'}
                ]
            },
            {
                'id': 'email3',
                'sender': 'newsletter@example.com',
                'recipient': 'user@example.com',
                'subject': 'Weekly Industry Updates',
                'body': """
                Hello,
                
                Here are this week's industry updates:
                
                - New product launches
                - Market trends
                - Competitor analysis
                
                Click here to read more.
                
                Regards,
                Newsletter Team
                """,
                'date': last_week.isoformat(),
                'read': True,
                'category': 'newsletters',
                'priority': 'low',
                'attachments': []
            },
            {
                'id': 'email4',
                'sender': 'client@example.com',
                'recipient': 'user@example.com',
                'subject': 'Feedback on Proposal',
                'body': """
                Hello,
                
                Thank you for sending the proposal. I've reviewed it and have some feedback:
                
                The pricing structure seems a bit high compared to other vendors. Could you provide a more competitive quote?
                
                I like the approach you've outlined, but I'm concerned about the timeline. Can we accelerate the delivery?
                
                Please let me know your thoughts.
                
                Best regards,
                Client
                """,
                'date': yesterday.isoformat(),
                'read': False,
                'category': 'inbox',
                'priority': 'high',
                'attachments': []
            },
            {
                'id': 'email5',
                'sender': 'support@example.com',
                'recipient': 'user@example.com',
                'subject': 'Your Support Ticket #12345',
                'body': """
                Dear User,
                
                Your support ticket #12345 has been resolved. Here's a summary of the issue and resolution:
                
                Issue: Unable to access the system
                Resolution: Reset user permissions and updated access controls
                
                If you continue to experience issues, please let us know.
                
                Thank you,
                Support Team
                """,
                'date': last_week.isoformat(),
                'read': True,
                'category': 'support',
                'priority': 'medium',
                'attachments': []
            }
        ]
        
        # Save demo data
        with open(demo_data_file, 'w') as f:
            json.dump(demo_emails, f, indent=2)
    
    return demo_emails

def initialize_user_components(user_id):
    """Initialize user-specific components."""
    global contextual_learning, proactive_notifications
    
    # Create data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    os.makedirs(data_dir, exist_ok=True)
    
    # Initialize contextual learning
    contextual_learning = ContextualLearningSystem(
        user_id=user_id,
        data_dir=data_dir
    )
    
    # Initialize proactive notifications
    proactive_notifications = ProactiveNotificationSystem(
        user_id=user_id,
        data_dir=data_dir
    )
    
    # Start notification thread
    proactive_notifications.start_notification_thread()

@app.route('/')
def index():
    """Render the index page."""
    return render_template('index.html')

@app.route('/auth', methods=['POST'])
def auth():
    """Handle authentication."""
    if request.method == 'POST':
        # In demo mode, just set a demo user
        if DEMO_MODE:
            session['user_id'] = 'demo_user'
            initialize_user_components(session['user_id'])
            return redirect(url_for('dashboard'))
        
        # In real mode, handle credential upload and OAuth flow
        if 'credentials' not in request.files:
            return render_template('index.html', error='No credentials file provided')
        
        file = request.files['credentials']
        if file.filename == '':
            return render_template('index.html', error='No credentials file selected')
        
        if file:
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
            
            # Initialize email retriever with credentials
            global email_retriever
            email_retriever = EmailRetriever(file_path)
            
            # Start OAuth flow
            auth_url = email_retriever.get_authorization_url()
            session['credentials_path'] = file_path
            
            return redirect(auth_url)
    
    return render_template('index.html')

@app.route('/oauth2callback')
def oauth2callback():
    """Handle OAuth callback."""
    # In demo mode, just redirect to dashboard
    if DEMO_MODE:
        return redirect(url_for('dashboard'))
    
    # In real mode, handle OAuth callback
    auth_code = request.args.get('code')
    credentials_path = session.get('credentials_path')
    
    if not auth_code or not credentials_path:
        return render_template('index.html', error='Authentication failed')
    
    # Complete OAuth flow
    global email_retriever
    email_retriever.complete_authorization(auth_code)
    
    # Set user ID
    session['user_id'] = email_retriever.get_user_email()
    
    # Initialize user-specific components
    initialize_user_components(session['user_id'])
    
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
def dashboard():
    """Render the dashboard page."""
    if 'user_id' not in session:
        return redirect(url_for('index'))
    
    # Load emails
    emails = []
    if DEMO_MODE:
        emails = load_demo_data()
    else:
        # Retrieve emails from Gmail
        if email_retriever:
            emails = email_retriever.get_emails(max_results=20)
    
    # Process emails
    processed_emails = []
    for email in emails:
        # Categorize email
        category = email_categorizer.categorize_email(email)
        email['category'] = category
        
        # Determine priority
        priority = email_categorizer.determine_priority(email)
        email['priority'] = priority
        
        # Summarize email
        summary = email_summarizer.summarize_email(email)
        email['summary'] = summary
        
        # Detect action items
        action_items = action_detector.detect_action_items(email)
        email['action_items'] = action_items
        
        # Detect calendar events
        calendar_events = action_detector.detect_calendar_events(email)
        email['calendar_events'] = calendar_events
        
        # Enhanced AI processing
        if session.get('user_id'):
            # Analyze sentiment
            sentiment = sentiment_analyzer.analyze_sentiment(email)
            email['sentiment'] = sentiment
            
            # Generate smart response
            response = smart_response.generate_response(email)
            email['smart_response'] = response
            
            # Extract tasks for workload management
            tasks = workload_manager.extract_tasks_from_email(email)
            email['tasks'] = tasks
            
            # Advanced NLP understanding
            nlp_analysis = advanced_nlp.analyze_email(email)
            email['nlp_analysis'] = nlp_analysis
            
            # Track interaction for contextual learning
            if contextual_learning:
                contextual_learning.track_email_interaction(
                    email['id'],
                    'read',
                    {
                        'sender': email.get('sender', ''),
                        'category': email.get('category', ''),
                        'subject': email.get('subject', ''),
                        'time_spent': 0  # Initial view
                    }
                )
            
            # Process for notifications
            if proactive_notifications:
                proactive_notifications.process_email_for_notifications(
                    email,
                    {
                        'sentiment': sentiment,
                        'action_items': action_items,
                        'deadlines': nlp_analysis.get('deadlines', [])
                    },
                    'high' if email.get('priority') == 'high' else 'medium'
                )
        
        processed_emails.append(email)
    
    # Generate digest
    digest = digest_generator.generate_digest(processed_emails)
    
    # Get workload metrics if available
    workload_metrics = None
    if session.get('user_id') and processed_emails:
        tasks = []
        for email in processed_emails:
            if 'tasks' in email:
                tasks.extend(email['tasks'])
        
        if tasks:
            workload_metrics = workload_manager.get_workload_metrics(tasks)
    
    # Get notifications if available
    notifications = []
    if session.get('user_id') and proactive_notifications:
        notifications = proactive_notifications.get_notification_history(limit=5)
    
    return render_template(
        'dashboard.html',
        emails=processed_emails,
        digest=digest,
        workload_metrics=workload_metrics,
        notifications=notifications
    )

@app.route('/api/emails')
def api_emails():
    """API endpoint to get emails."""
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    # Load emails
    emails = []
    if DEMO_MODE:
        emails = load_demo_data()
    else:
        # Retrieve emails from Gmail
        if email_retriever:
            emails = email_retriever.get_emails(max_results=20)
    
    return jsonify(emails)

@app.route('/api/email/<email_id>')
def api_email(email_id):
    """API endpoint to get a specific email."""
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    # Load emails
    emails = []
    if DEMO_MODE:
        emails = load_demo_data()
    else:
        # Retrieve emails from Gmail
        if email_retriever:
            emails = email_retriever.get_emails(max_results=20)
    
    # Find email by ID
    email = next((e for e in emails if e['id'] == email_id), None)
    if not email:
        return jsonify({'error': 'Email not found'}), 404
    
    return jsonify(email)

@app.route('/api/email/<email_id>/smart_response')
def api_smart_response(email_id):
    """API endpoint to get a smart response for an email."""
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    # Load emails
    emails = []
    if DEMO_MODE:
        emails = load_demo_data()
    else:
        # Retrieve emails from Gmail
        if email_retriever:
            emails = email_retriever.get_emails(max_results=20)
    
    # Find email by ID
    email = next((e for e in emails if e['id'] == email_id), None)
    if not email:
        return jsonify({'error': 'Email not found'}), 404
    
    # Generate smart response
    response = smart_response.generate_response(email)
    
    return jsonify(response)

@app.route('/api/email/<email_id>/sentiment')
def api_sentiment(email_id):
    """API endpoint to get sentiment analysis for an email."""
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    # Load emails
    emails = []
    if DEMO_MODE:
        emails = load_demo_data()
    else:
        # Retrieve emails from Gmail
        if email_retriever:
            emails = email_retriever.get_emails(max_results=20)
    
    # Find email by ID
    email = next((e for e in emails if e['id'] == email_id), None)
    if not email:
        return jsonify({'error': 'Email not found'}), 404
    
    # Analyze sentiment
    sentiment = sentiment_analyzer.analyze_sentiment(email)
    
    return jsonify(sentiment)

@app.route('/api/email/<email_id>/nlp_analysis')
def api_nlp_analysis(email_id):
    """API endpoint to get NLP analysis for an email."""
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    # Load emails
    emails = []
    if DEMO_MODE:
        emails = load_demo_data()
    else:
        # Retrieve emails from Gmail
        if email_retriever:
            emails = email_retriever.get_emails(max_results=20)
    
    # Find email by ID
    email = next((e for e in emails if e['id'] == email_id), None)
    if not email:
        return jsonify({'error': 'Email not found'}), 404
    
    # Advanced NLP understanding
    nlp_analysis = advanced_nlp.analyze_email(email)
    
    return jsonify(nlp_analysis)

@app.route('/api/workload')
def api_workload():
    """API endpoint to get workload metrics."""
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    # Load emails
    emails = []
    if DEMO_MODE:
        emails = load_demo_data()
    else:
        # Retrieve emails from Gmail
        if email_retriever:
            emails = email_retriever.get_emails(max_results=20)
    
    # Extract tasks from emails
    tasks = []
    for email in emails:
        email_tasks = workload_manager.extract_tasks_from_email(email)
        tasks.extend(email_tasks)
    
    # Get workload metrics
    metrics = workload_manager.get_workload_metrics(tasks)
    
    # Get workload recommendations
    recommendations = workload_manager.get_workload_recommendations(tasks)
    
    return jsonify({
        'metrics': metrics,
        'recommendations': recommendations
    })

@app.route('/api/notifications')
def api_notifications():
    """API endpoint to get notifications."""
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    if not proactive_notifications:
        return jsonify([])
    
    # Get notifications
    notifications = proactive_notifications.get_notification_history(limit=10)
    
    return jsonify(notifications)

@app.route('/api/digest')
def api_digest():
    """API endpoint to get email digest."""
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    # Load emails
    emails = []
    if DEMO_MODE:
        emails = load_demo_data()
    else:
        # Retrieve emails from Gmail
        if email_retriever:
            emails = email_retriever.get_emails(max_results=20)
    
    # Generate digest
    digest = digest_generator.generate_digest(emails)
    
    return jsonify(digest)

@app.route('/api/user/preferences')
def api_user_preferences():
    """API endpoint to get user preferences."""
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    if not contextual_learning:
        return jsonify({})
    
    # Get user preferences
    preferences = contextual_learning.get_user_preferences()
    
    return jsonify(preferences)

@app.route('/api/user/preferences', methods=['POST'])
def api_update_user_preferences():
    """API endpoint to update user preferences."""
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    if not contextual_learning:
        return jsonify({'error': 'Contextual learning not initialized'}), 500
    
    # Get preferences from request
    preferences = request.json
    
    # Update preferences
    updated_preferences = contextual_learning.update_user_preferences(preferences)
    
    return jsonify(updated_preferences)

@app.route('/api/user/insights')
def api_user_insights():
    """API endpoint to get user behavior insights."""
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    if not contextual_learning:
        return jsonify({})
    
    # Get behavior insights
    insights = contextual_learning.analyze_behavior_patterns()
    
    return jsonify(insights)

@app.route('/logout')
def logout():
    """Handle logout."""
    # Stop notification thread if running
    if proactive_notifications and proactive_notifications.thread_running:
        proactive_notifications.stop_notification_thread()
    
    # Clear session
    session.clear()
    
    return redirect(url_for('index'))

@app.errorhandler(404)
def page_not_found(e):
    """Handle 404 errors."""
    return render_template('index.html', error='Page not found'), 404

@app.errorhandler(500)
def server_error(e):
    """Handle 500 errors."""
    return render_template('index.html', error='Server error'), 500

if __name__ == '__main__':
    # Load demo data in demo mode
    if DEMO_MODE:
        load_demo_data()
    
    # Run the app
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)), debug=False)
