"""
Contextual Learning module for Email Management AI Agent.
Enables the system to learn from user behavior and adapt to individual work patterns.
"""

import json
import os
import datetime
import numpy as np
from collections import defaultdict, Counter

class ContextualLearningSystem:
    """
    Handles learning from user behavior and adapting functionality to match individual work patterns.
    """
    
    def __init__(self, user_id, data_dir='/home/ubuntu/email_agent/data'):
        """
        Initialize the contextual learning system.
        
        Args:
            user_id (str): Unique identifier for the user
            data_dir (str): Directory to store learning data
        """
        self.user_id = user_id
        self.data_dir = data_dir
        
        # Create data directory if it doesn't exist
        os.makedirs(os.path.join(data_dir, 'user_models'), exist_ok=True)
        
        # User model file path
        self.model_path = os.path.join(data_dir, 'user_models', f'{user_id}_model.json')
        
        # Initialize or load user model
        self.user_model = self._load_user_model()
        
        # Initialize behavior tracking
        self.behavior_tracking = {
            'email_interactions': [],
            'response_patterns': [],
            'time_patterns': [],
            'category_adjustments': []
        }
        
        # Learning parameters
        self.learning_rate = 0.2  # How quickly the model adapts to new behaviors
        self.min_observations = 5  # Minimum observations before making adaptations
    
    def _load_user_model(self):
        """
        Load user model from file or initialize a new one.
        
        Returns:
            dict: User model
        """
        if os.path.exists(self.model_path):
            try:
                with open(self.model_path, 'r') as f:
                    return json.load(f)
            except Exception as e:
                print(f"Error loading user model: {e}")
                return self._initialize_user_model()
        else:
            return self._initialize_user_model()
    
    def _initialize_user_model(self):
        """
        Initialize a new user model.
        
        Returns:
            dict: New user model
        """
        return {
            'user_id': self.user_id,
            'created_at': datetime.datetime.now().isoformat(),
            'updated_at': datetime.datetime.now().isoformat(),
            'version': '1.0',
            'interaction_count': 0,
            'preferences': {
                'email_processing': {
                    'preferred_times': [],
                    'processing_frequency': 'multiple_daily',
                    'batch_processing': False,
                    'auto_categorization': True,
                    'auto_prioritization': True
                },
                'response_preferences': {
                    'response_style': 'neutral',
                    'response_length': 'medium',
                    'greeting_style': 'standard',
                    'closing_style': 'standard',
                    'formality_level': 'neutral'
                },
                'notification_preferences': {
                    'notification_frequency': 'medium',
                    'urgent_only': False,
                    'quiet_hours': {
                        'enabled': False,
                        'start': '22:00',
                        'end': '08:00'
                    }
                },
                'ui_preferences': {
                    'default_view': 'inbox',
                    'theme': 'light',
                    'density': 'medium',
                    'sort_order': 'date_desc'
                }
            },
            'learned_patterns': {
                'email_importance': {},
                'sender_importance': {},
                'category_mapping': {},
                'response_patterns': {},
                'time_patterns': {
                    'active_hours': {},
                    'email_checking_times': [],
                    'response_times': {}
                },
                'topic_interests': {}
            },
            'custom_categories': [],
            'sender_relationships': {}
        }
    
    def _save_user_model(self):
        """
        Save user model to file.
        
        Returns:
            bool: Success indicator
        """
        try:
            # Update timestamp
            self.user_model['updated_at'] = datetime.datetime.now().isoformat()
            
            # Save to file
            with open(self.model_path, 'w') as f:
                json.dump(self.user_model, f, indent=2)
            
            return True
        except Exception as e:
            print(f"Error saving user model: {e}")
            return False
    
    def track_email_interaction(self, email_id, action, metadata=None):
        """
        Track user interaction with an email.
        
        Args:
            email_id (str): Email identifier
            action (str): Action performed (read, reply, delete, archive, flag, etc.)
            metadata (dict, optional): Additional metadata about the interaction
            
        Returns:
            bool: Success indicator
        """
        # Create interaction record
        interaction = {
            'email_id': email_id,
            'action': action,
            'timestamp': datetime.datetime.now().isoformat(),
            'metadata': metadata or {}
        }
        
        # Add to behavior tracking
        self.behavior_tracking['email_interactions'].append(interaction)
        
        # Update interaction count
        self.user_model['interaction_count'] += 1
        
        # Process the interaction for learning
        self._process_interaction(interaction)
        
        # Save model periodically (every 10 interactions)
        if self.user_model['interaction_count'] % 10 == 0:
            self._save_user_model()
        
        return True
    
    def _process_interaction(self, interaction):
        """
        Process an interaction for learning.
        
        Args:
            interaction (dict): Interaction data
        """
        action = interaction['action']
        metadata = interaction['metadata']
        
        # Process based on action type
        if action == 'read':
            self._process_read_action(interaction)
        elif action == 'reply':
            self._process_reply_action(interaction)
        elif action in ['delete', 'archive']:
            self._process_disposition_action(interaction)
        elif action == 'flag':
            self._process_flag_action(interaction)
        elif action == 'categorize':
            self._process_categorize_action(interaction)
        elif action == 'prioritize':
            self._process_prioritize_action(interaction)
        
        # Track time patterns
        self._track_time_pattern(action, metadata)
    
    def _process_read_action(self, interaction):
        """
        Process a read action.
        
        Args:
            interaction (dict): Interaction data
        """
        metadata = interaction['metadata']
        
        # Extract relevant data
        email_id = interaction['email_id']
        sender = metadata.get('sender')
        category = metadata.get('category')
        subject = metadata.get('subject', '')
        time_spent = metadata.get('time_spent', 0)  # seconds spent reading
        
        # Update sender importance based on time spent
        if sender and time_spent > 0:
            self._update_sender_importance(sender, time_spent)
        
        # Update topic interests based on subject
        if subject:
            self._update_topic_interests(subject, time_spent)
    
    def _process_reply_action(self, interaction):
        """
        Process a reply action.
        
        Args:
            interaction (dict): Interaction data
        """
        metadata = interaction['metadata']
        
        # Extract relevant data
        email_id = interaction['email_id']
        sender = metadata.get('sender')
        category = metadata.get('category')
        response_time = metadata.get('response_time', 0)  # seconds between receiving and replying
        response_length = metadata.get('response_length', 0)  # characters in response
        
        # Update sender importance based on quick response
        if sender and response_time is not None:
            importance_factor = self._calculate_response_importance(response_time)
            self._update_sender_importance(sender, importance_factor)
        
        # Track response pattern
        if sender and response_time is not None and response_length is not None:
            self._track_response_pattern(sender, response_time, response_length)
    
    def _process_disposition_action(self, interaction):
        """
        Process a disposition action (delete/archive).
        
        Args:
            interaction (dict): Interaction data
        """
        metadata = interaction['metadata']
        
        # Extract relevant data
        email_id = interaction['email_id']
        sender = metadata.get('sender')
        category = metadata.get('category')
        read_before_action = metadata.get('read_before_action', False)
        
        # Update sender importance (negative if deleted without reading)
        if sender:
            if interaction['action'] == 'delete' and not read_before_action:
                self._update_sender_importance(sender, -5)  # Negative importance
    
    def _process_flag_action(self, interaction):
        """
        Process a flag action.
        
        Args:
            interaction (dict): Interaction data
        """
        metadata = interaction['metadata']
        
        # Extract relevant data
        email_id = interaction['email_id']
        sender = metadata.get('sender')
        category = metadata.get('category')
        flag_type = metadata.get('flag_type', 'important')
        
        # Update sender importance based on flagging
        if sender:
            importance_factor = 5 if flag_type == 'important' else 3
            self._update_sender_importance(sender, importance_factor)
        
        # Update email importance
        if email_id:
            self._update_email_importance(email_id, flag_type)
    
    def _process_categorize_action(self, interaction):
        """
        Process a categorize action.
        
        Args:
            interaction (dict): Interaction data
        """
        metadata = interaction['metadata']
        
        # Extract relevant data
        email_id = interaction['email_id']
        sender = metadata.get('sender')
        original_category = metadata.get('original_category')
        new_category = metadata.get('new_category')
        
        # Track category adjustment
        if original_category and new_category and original_category != new_category:
            self._track_category_adjustment(sender, original_category, new_category)
    
    def _process_prioritize_action(self, interaction):
        """
        Process a prioritize action.
        
        Args:
            interaction (dict): Interaction data
        """
        metadata = interaction['metadata']
        
        # Extract relevant data
        email_id = interaction['email_id']
        sender = metadata.get('sender')
        original_priority = metadata.get('original_priority')
        new_priority = metadata.get('new_priority')
        
        # Update sender importance based on priority change
        if sender and original_priority and new_priority:
            priority_change = self._calculate_priority_change(original_priority, new_priority)
            self._update_sender_importance(sender, priority_change)
    
    def _update_sender_importance(self, sender, importance_factor):
        """
        Update importance of a sender.
        
        Args:
            sender (str): Email sender
            importance_factor (float): Importance factor to apply
        """
        # Initialize if not exists
        if sender not in self.user_model['learned_patterns']['sender_importance']:
            self.user_model['learned_patterns']['sender_importance'][sender] = {
                'importance_score': 0,
                'interaction_count': 0,
                'last_interaction': None
            }
        
        # Get current data
        sender_data = self.user_model['learned_patterns']['sender_importance'][sender]
        
        # Update importance score with learning rate
        current_score = sender_data['importance_score']
        interaction_count = sender_data['interaction_count']
        
        # Apply diminishing learning rate as interactions increase
        effective_learning_rate = self.learning_rate / (1 + (interaction_count / 50))
        
        # Update score
        new_score = current_score + (importance_factor * effective_learning_rate)
        
        # Ensure score stays within reasonable bounds
        new_score = max(-10, min(10, new_score))
        
        # Update data
        sender_data['importance_score'] = new_score
        sender_data['interaction_count'] += 1
        sender_data['last_interaction'] = datetime.datetime.now().isoformat()
        
        # Update sender relationship if score changes significantly
        if abs(new_score - current_score) > 1:
            self._update_sender_relationship(sender, new_score)
    
    def _update_sender_relationship(self, sender, importance_score):
        """
        Update relationship status with a sender.
        
        Args:
            sender (str): Email sender
            importance_score (float): Current importance score
        """
        # Determine relationship status based on importance score
        if importance_score >= 7:
            relationship = 'vip'
        elif importance_score >= 4:
            relationship = 'important'
        elif importance_score >= 1:
            relationship = 'regular'
        elif importance_score >= -2:
            relationship = 'neutral'
        else:
            relationship = 'low_priority'
        
        # Update sender relationships
        self.user_model['sender_relationships'][sender] = relationship
    
    def _update_email_importance(self, email_id, flag_type):
        """
        Update importance of an email.
        
        Args:
            email_id (str): Email identifier
            flag_type (str): Type of flag
        """
        # Map flag types to importance scores
        importance_map = {
            'important': 5,
            'follow_up': 4,
            'to_do': 4,
            'custom': 3
        }
        
        importance_score = importance_map.get(flag_type, 3)
        
        # Update email importance
        self.user_model['learned_patterns']['email_importance'][email_id] = importance_score
    
    def _update_topic_interests(self, subject, time_spent):
        """
        Update topic interests based on email subject and time spent.
        
        Args:
            subject (str): Email subject
            time_spent (int): Time spent reading in seconds
        """
        # Extract keywords from subject
        keywords = self._extract_keywords(subject)
        
        # Calculate interest factor based on time spent
        interest_factor = min(time_spent / 60, 5)  # Cap at 5 minutes
        
        # Update topic interests
        for keyword in keywords:
            if keyword not in self.user_model['learned_patterns']['topic_interests']:
                self.user_model['learned_patterns']['topic_interests'][keyword] = {
                    'interest_score': 0,
                    'occurrence_count': 0
                }
            
            # Update interest score
            topic_data = self.user_model['learned_patterns']['topic_interests'][keyword]
            current_score = topic_data['interest_score']
            occurrence_count = topic_data['occurrence_count']
            
            # Apply diminishing learning rate as occurrences increase
            effective_learning_rate = self.learning_rate / (1 + (occurrence_count / 20))
            
            # Update score
            new_score = current_score + (interest_factor * effective_learning_rate)
            
            # Ensure score stays within reasonable bounds
            new_score = max(0, min(10, new_score))
            
            # Update data
            topic_data['interest_score'] = new_score
            topic_data['occurrence_count'] += 1
    
    def _extract_keywords(self, text):
        """
        Extract keywords from text.
        
        Args:
            text (str): Text to extract keywords from
            
        Returns:
            list: Extracted keywords
        """
        # This is a simplified implementation
        # A real implementation would use NLP techniques for keyword extraction
        
        # Remove common words and punctuation
        common_words = {'re', 'fwd', 'fw', 'the', 'a', 'an', 'and', 'or', 'but', 'is', 'are', 'was', 'were', 
                       'to', 'of', 'in', 'for', 'with', 'on', 'at', 'from', 'by'}
        
        # Split text into words
        words = text.lower().split()
        
        # Filter words
        keywords = [word for word in words if word not in common_words and len(word) > 3]
        
        return keywords
    
    def _track_response_pattern(self, sender, response_time, response_length):
        """
        Track response pattern for a sender.
        
        Args:
            sender (str): Email sender
            response_time (int): Response time in seconds
            response_length (int): Response length in characters
        """
        # Create response pattern record
        pattern = {
            'sender': sender,
            'response_time': response_time,
            'response_length': response_length,
            'timestamp': datetime.datetime.now().isoformat()
        }
        
        # Add to behavior tracking
        self.behavior_tracking['response_patterns'].append(pattern)
        
        # Update response patterns in user model
        if sender not in self.user_model['learned_patterns']['response_patterns']:
            self.user_model['learned_patterns']['response_patterns'][sender] = {
                'avg_response_time': response_time,
                'avg_response_length': response_length,
                'response_count': 1,
                'last_response': datetime.datetime.now().isoformat()
            }
        else:
            # Get current data
            pattern_data = self.user_model['learned_patterns']['response_patterns'][sender]
            
            # Update averages
            current_avg_time = pattern_data['avg_response_time']
            current_avg_length = pattern_data['avg_response_length']
            response_count = pattern_data['response_count']
            
            # Calculate new averages
            new_avg_time = ((current_avg_time * response_count) + response_time) / (response_count + 1)
            new_avg_length = ((current_avg_length * response_count) + response_length) / (response_count + 1)
            
            # Update data
            pattern_data['avg_response_time'] = new_avg_time
            pattern_data['avg_response_length'] = new_avg_length
            pattern_data['response_count'] += 1
            pattern_data['last_response'] = datetime.datetime.now().isoformat()
    
    def _track_time_pattern(self, action, metadata):
        """
        Track time pattern for user actions.
        
        Args:
            action (str): Action performed
            metadata (dict): Action metadata
        """
        # Get current time
        now = datetime.datetime.now()
        hour = now.hour
        
        # Create time pattern record
        pattern = {
            'action': action,
            'hour': hour,
            'day_of_week': now.weekday(),
            'timestamp': now.isoformat()
        }
        
        # Add to behavior tracking
        self.behavior_tracking['time_patterns'].append(pattern)
        
        # Update active hours in user model
        hour_key = str(hour)
        if hour_key not in self.user_model['learned_patterns']['time_patterns']['active_hours']:
            self.user_model['learned_patterns']['time_patterns']['active_hours'][hour_key] = 1
        else:
            self.user_model['learned_patterns']['time_patterns']['active_hours'][hour_key] += 1
        
        # Update email checking times if this is a read action
        if action == 'read':
            self.user_model['learned_patterns']['time_patterns']['email_checking_times'].append({
                'hour': hour,
                'day_of_week': now.weekday(),
                'timestamp': now.isoformat()
            })
            
            # Keep only the most recent 100 checking times
            if len(self.user_model['learned_patterns']['time_patterns']['email_checking_times']) > 100:
                self.user_model['learned_patterns']['time_patterns']['email_checking_times'] = \
                    self.user_model['learned_patterns']['time_patterns']['email_checking_times'][-100:]
        
        # Update response times if this is a reply action
        if action == 'reply' and 'sender' in metadata:
            sender = metadata['sender']
            if sender not in self.user_model['learned_patterns']['time_patterns']['response_times']:
                self.user_model['learned_patterns']['time_patterns']['response_times'][sender] = []
            
            self.user_model['learned_patterns']['time_patterns']['response_times'][sender].append({
                'hour': hour,
                'day_of_week': now.weekday(),
                'timestamp': now.isoformat()
            })
            
            # Keep only the most recent 20 response times per sender
            if len(self.user_model['learned_patterns']['time_patterns']['response_times'][sender]) > 20:
                self.user_model['learned_patterns']['time_patterns']['response_times'][sender] = \
                    self.user_model['learned_patterns']['time_patterns']['response_times'][sender][-20:]
    
    def _track_category_adjustment(self, sender, original_category, new_category):
        """
        Track category adjustment.
        
        Args:
            sender (str): Email sender
            original_category (str): Original category
            new_category (str): New category
        """
        # Create category adjustment record
        adjustment = {
            'sender': sender,
            'original_category': original_category,
            'new_category': new_category,
            'timestamp': datetime.datetime.now().isoformat()
        }
        
        # Add to behavior tracking
        self.behavior_tracking['category_adjustments'].append(adjustment)
        
        # Update category mapping in user model
        key = f"{sender}:{original_category}"
        self.user_model['learned_patterns']['category_mapping'][key] = new_category
        
        # Add to custom categories if not already present
        if new_category not in self.user_model['custom_categories']:
            self.user_model['custom_categories'].append(new_category)
    
    def _calculate_response_importance(self, response_time):
        """
        Calculate importance factor based on response time.
        
        Args:
            response_time (int): Response time in seconds
            
        Returns:
            float: Importance factor
        """
        # Quick responses indicate importance
        if response_time < 300:  # 5 minutes
            return 5
        elif response_time < 1800:  # 30 minutes
            return 3
        elif response_time < 3600:  # 1 hour
            return 2
        elif response_time < 86400:  # 1 day
            return 1
        else:
            return 0.5
    
    def _calculate_priority_change(self, original_priority, new_priority):
        """
        Calculate importance factor based on priority change.
        
        Args:
            original_priority (str): Original priority
            new_priority (str): New priority
            
        Returns:
            float: Importance factor
        """
        # Map priorities to numeric values
        priority_map = {
            'critical': 5,
            'high': 4,
            'medium': 3,
            'low': 2,
            'none': 1
        }
        
        # Calculate change
        original_value = priority_map.get(original_priority, 3)
        new_value = priority_map.get(new_priority, 3)
        
        # Return difference
        return new_value - original_value
    
    def analyze_behavior_patterns(self):
        """
        Analyze behavior patterns to generate insights.
        
        Returns:
            dict: Behavior insights
        """
        # Ensure we have enough data
        if self.user_model['interaction_count'] < self.min_observations:
            return {
                'status': 'insufficient_data',
                'message': f"Need at least {self.min_observations} interactions for meaningful analysis",
                'interaction_count': self.user_model['interaction_count']
            }
        
        # Analyze time patterns
        time_insights = self._analyze_time_patterns()
        
        # Analyze response patterns
        response_insights = self._analyze_response_patterns()
        
        # Analyze category patterns
        category_insights = self._analyze_category_patterns()
        
        # Analyze sender importance
        sender_insights = self._analyze_sender_importance()
        
        # Analyze topic interests
        topic_insights = self._analyze_topic_interests()
        
        # Combine insights
        insights = {
            'status': 'success',
            'interaction_count': self.user_model['interaction_count'],
            'time_insights': time_insights,
            'response_insights': response_insights,
            'category_insights': category_insights,
            'sender_insights': sender_insights,
            'topic_insights': topic_insights
        }
        
        return insights
    
    def _analyze_time_patterns(self):
        """
        Analyze time patterns.
        
        Returns:
            dict: Time pattern insights
        """
        # Get active hours
        active_hours = self.user_model['learned_patterns']['time_patterns']['active_hours']
        
        # Convert to list of (hour, count) tuples
        hour_counts = [(int(hour), count) for hour, count in active_hours.items()]
        
        # Sort by hour
        hour_counts.sort()
        
        # Find peak hours (top 3)
        peak_hours = sorted(hour_counts, key=lambda x: x[1], reverse=True)[:3]
        
        # Determine preferred email checking times
        checking_times = self.user_model['learned_patterns']['time_patterns']['email_checking_times']
        
        # Count occurrences by hour
        hour_distribution = defaultdict(int)
        for check in checking_times:
            hour_distribution[check['hour']] += 1
        
        # Find most common checking hours
        common_checking_hours = sorted([(hour, count) for hour, count in hour_distribution.items()], 
                                      key=lambda x: x[1], reverse=True)[:3]
        
        # Determine if user prefers batch processing
        # (concentrated checking at specific times vs. spread throughout day)
        total_checks = sum(hour_distribution.values())
        top_hours_percentage = sum(count for _, count in common_checking_hours) / total_checks if total_checks > 0 else 0
        
        batch_processing = top_hours_percentage > 0.7  # If top hours account for >70% of checks
        
        # Determine checking frequency
        if len(checking_times) < 10:
            frequency = 'insufficient_data'
        else:
            # Analyze timestamps to determine frequency
            timestamps = [datetime.datetime.fromisoformat(check['timestamp']) for check in checking_times]
            timestamps.sort()
            
            # Group by day
            days = defaultdict(list)
            for ts in timestamps:
                day_key = ts.strftime('%Y-%m-%d')
                days[day_key].append(ts)
            
            # Calculate average checks per day
            avg_checks_per_day = sum(len(checks) for checks in days.values()) / len(days) if days else 0
            
            if avg_checks_per_day < 2:
                frequency = 'daily'
            elif avg_checks_per_day < 5:
                frequency = 'few_times_daily'
            else:
                frequency = 'multiple_daily'
        
        # Create time insights
        time_insights = {
            'peak_activity_hours': [hour for hour, _ in peak_hours],
            'common_checking_hours': [hour for hour, _ in common_checking_hours],
            'batch_processing': batch_processing,
            'checking_frequency': frequency
        }
        
        # Update user preferences based on insights
        self.user_model['preferences']['email_processing']['preferred_times'] = [hour for hour, _ in common_checking_hours]
        self.user_model['preferences']['email_processing']['processing_frequency'] = frequency
        self.user_model['preferences']['email_processing']['batch_processing'] = batch_processing
        
        return time_insights
    
    def _analyze_response_patterns(self):
        """
        Analyze response patterns.
        
        Returns:
            dict: Response pattern insights
        """
        # Get response patterns
        response_patterns = self.user_model['learned_patterns']['response_patterns']
        
        # Skip if insufficient data
        if not response_patterns:
            return {
                'status': 'insufficient_data',
                'message': 'No response patterns recorded yet'
            }
        
        # Calculate average response times and lengths
        avg_times = [data['avg_response_time'] for data in response_patterns.values()]
        avg_lengths = [data['avg_response_length'] for data in response_patterns.values()]
        
        overall_avg_time = sum(avg_times) / len(avg_times) if avg_times else 0
        overall_avg_length = sum(avg_lengths) / len(avg_lengths) if avg_lengths else 0
        
        # Determine response style
        if overall_avg_length < 200:
            response_style = 'concise'
        elif overall_avg_length < 500:
            response_style = 'balanced'
        else:
            response_style = 'detailed'
        
        # Determine response length
        if overall_avg_length < 100:
            response_length = 'short'
        elif overall_avg_length < 300:
            response_length = 'medium'
        else:
            response_length = 'long'
        
        # Find VIP senders (those with fastest response times)
        vip_senders = sorted([(sender, data['avg_response_time']) for sender, data in response_patterns.items()], 
                            key=lambda x: x[1])[:5]
        
        # Create response insights
        response_insights = {
            'avg_response_time_seconds': overall_avg_time,
            'avg_response_length_chars': overall_avg_length,
            'response_style': response_style,
            'response_length': response_length,
            'vip_senders': [sender for sender, _ in vip_senders]
        }
        
        # Update user preferences based on insights
        self.user_model['preferences']['response_preferences']['response_style'] = response_style
        self.user_model['preferences']['response_preferences']['response_length'] = response_length
        
        return response_insights
    
    def _analyze_category_patterns(self):
        """
        Analyze category patterns.
        
        Returns:
            dict: Category pattern insights
        """
        # Get category mapping
        category_mapping = self.user_model['learned_patterns']['category_mapping']
        
        # Skip if insufficient data
        if not category_mapping:
            return {
                'status': 'insufficient_data',
                'message': 'No category adjustments recorded yet'
            }
        
        # Count occurrences of each target category
        category_counts = Counter(category_mapping.values())
        
        # Find most common categories
        common_categories = category_counts.most_common(5)
        
        # Find sender-specific categories
        sender_categories = defaultdict(list)
        for key, category in category_mapping.items():
            if ':' in key:
                sender = key.split(':')[0]
                sender_categories[sender].append(category)
        
        # Find most common category for each sender
        sender_preferred_categories = {}
        for sender, categories in sender_categories.items():
            if categories:
                sender_preferred_categories[sender] = Counter(categories).most_common(1)[0][0]
        
        # Create category insights
        category_insights = {
            'common_categories': [category for category, _ in common_categories],
            'sender_preferred_categories': sender_preferred_categories,
            'custom_categories': self.user_model['custom_categories']
        }
        
        return category_insights
    
    def _analyze_sender_importance(self):
        """
        Analyze sender importance.
        
        Returns:
            dict: Sender importance insights
        """
        # Get sender importance
        sender_importance = self.user_model['learned_patterns']['sender_importance']
        
        # Skip if insufficient data
        if not sender_importance:
            return {
                'status': 'insufficient_data',
                'message': 'No sender importance data recorded yet'
            }
        
        # Sort senders by importance score
        sorted_senders = sorted([(sender, data['importance_score']) for sender, data in sender_importance.items()], 
                               key=lambda x: x[1], reverse=True)
        
        # Get top and bottom senders
        top_senders = sorted_senders[:5]
        bottom_senders = sorted_senders[-5:] if len(sorted_senders) >= 5 else []
        
        # Create sender importance insights
        sender_insights = {
            'top_senders': [{'sender': sender, 'score': score} for sender, score in top_senders],
            'bottom_senders': [{'sender': sender, 'score': score} for sender, score in bottom_senders],
            'sender_relationships': self.user_model['sender_relationships']
        }
        
        return sender_insights
    
    def _analyze_topic_interests(self):
        """
        Analyze topic interests.
        
        Returns:
            dict: Topic interest insights
        """
        # Get topic interests
        topic_interests = self.user_model['learned_patterns']['topic_interests']
        
        # Skip if insufficient data
        if not topic_interests:
            return {
                'status': 'insufficient_data',
                'message': 'No topic interest data recorded yet'
            }
        
        # Sort topics by interest score
        sorted_topics = sorted([(topic, data['interest_score']) for topic, data in topic_interests.items()], 
                              key=lambda x: x[1], reverse=True)
        
        # Get top topics
        top_topics = sorted_topics[:10]
        
        # Create topic interest insights
        topic_insights = {
            'top_topics': [{'topic': topic, 'score': score} for topic, score in top_topics]
        }
        
        return topic_insights
    
    def get_personalized_recommendations(self):
        """
        Generate personalized recommendations based on learned patterns.
        
        Returns:
            dict: Personalized recommendations
        """
        # Ensure we have enough data
        if self.user_model['interaction_count'] < self.min_observations:
            return {
                'status': 'insufficient_data',
                'message': f"Need at least {self.min_observations} interactions for meaningful recommendations",
                'interaction_count': self.user_model['interaction_count']
            }
        
        # Analyze behavior patterns
        insights = self.analyze_behavior_patterns()
        
        # Generate email processing recommendations
        processing_recommendations = self._generate_processing_recommendations(insights)
        
        # Generate response recommendations
        response_recommendations = self._generate_response_recommendations(insights)
        
        # Generate notification recommendations
        notification_recommendations = self._generate_notification_recommendations(insights)
        
        # Generate UI recommendations
        ui_recommendations = self._generate_ui_recommendations(insights)
        
        # Combine recommendations
        recommendations = {
            'status': 'success',
            'processing_recommendations': processing_recommendations,
            'response_recommendations': response_recommendations,
            'notification_recommendations': notification_recommendations,
            'ui_recommendations': ui_recommendations
        }
        
        return recommendations
    
    def _generate_processing_recommendations(self, insights):
        """
        Generate email processing recommendations.
        
        Args:
            insights (dict): Behavior insights
            
        Returns:
            dict: Processing recommendations
        """
        recommendations = {}
        
        # Recommend optimal processing times
        time_insights = insights.get('time_insights', {})
        if 'common_checking_hours' in time_insights and time_insights['common_checking_hours']:
            recommendations['optimal_processing_times'] = time_insights['common_checking_hours']
        
        # Recommend batch processing if user shows that pattern
        if 'batch_processing' in time_insights:
            recommendations['batch_processing'] = time_insights['batch_processing']
        
        # Recommend processing frequency
        if 'checking_frequency' in time_insights:
            recommendations['processing_frequency'] = time_insights['checking_frequency']
        
        # Recommend sender-specific categories
        category_insights = insights.get('category_insights', {})
        if 'sender_preferred_categories' in category_insights:
            recommendations['sender_categories'] = category_insights['sender_preferred_categories']
        
        return recommendations
    
    def _generate_response_recommendations(self, insights):
        """
        Generate response recommendations.
        
        Args:
            insights (dict): Behavior insights
            
        Returns:
            dict: Response recommendations
        """
        recommendations = {}
        
        # Recommend response style
        response_insights = insights.get('response_insights', {})
        if 'response_style' in response_insights:
            recommendations['response_style'] = response_insights['response_style']
        
        # Recommend response length
        if 'response_length' in response_insights:
            recommendations['response_length'] = response_insights['response_length']
        
        # Recommend VIP senders for prioritized responses
        if 'vip_senders' in response_insights:
            recommendations['priority_senders'] = response_insights['vip_senders']
        
        return recommendations
    
    def _generate_notification_recommendations(self, insights):
        """
        Generate notification recommendations.
        
        Args:
            insights (dict): Behavior insights
            
        Returns:
            dict: Notification recommendations
        """
        recommendations = {}
        
        # Recommend quiet hours based on activity patterns
        time_insights = insights.get('time_insights', {})
        if 'peak_activity_hours' in time_insights:
            active_hours = time_insights['peak_activity_hours']
            
            # Find continuous blocks of inactive hours
            all_hours = set(range(24))
            inactive_hours = all_hours - set(active_hours)
            
            # Find the longest continuous block
            if inactive_hours:
                # Convert to list and sort
                inactive_list = sorted(list(inactive_hours))
                
                # Find continuous blocks
                blocks = []
                current_block = [inactive_list[0]]
                
                for i in range(1, len(inactive_list)):
                    if inactive_list[i] == inactive_list[i-1] + 1:
                        current_block.append(inactive_list[i])
                    else:
                        blocks.append(current_block)
                        current_block = [inactive_list[i]]
                
                # Add the last block
                blocks.append(current_block)
                
                # Handle wrap-around case (e.g., 22, 23, 0, 1)
                if blocks and blocks[0][0] == 0 and blocks[-1][-1] == 23:
                    blocks[0] = blocks[-1] + blocks[0]
                    blocks.pop()
                
                # Find the longest block
                longest_block = max(blocks, key=len)
                
                if len(longest_block) >= 6:  # At least 6 hours of inactivity
                    start_hour = longest_block[0]
                    end_hour = (longest_block[-1] + 1) % 24  # End hour is exclusive
                    
                    recommendations['quiet_hours'] = {
                        'enabled': True,
                        'start': f"{start_hour:02d}:00",
                        'end': f"{end_hour:02d}:00"
                    }
        
        # Recommend notification frequency based on email checking frequency
        if 'checking_frequency' in time_insights:
            frequency = time_insights['checking_frequency']
            
            if frequency == 'daily':
                recommendations['notification_frequency'] = 'low'
            elif frequency == 'few_times_daily':
                recommendations['notification_frequency'] = 'medium'
            else:
                recommendations['notification_frequency'] = 'high'
        
        return recommendations
    
    def _generate_ui_recommendations(self, insights):
        """
        Generate UI recommendations.
        
        Args:
            insights (dict): Behavior insights
            
        Returns:
            dict: UI recommendations
        """
        recommendations = {}
        
        # Recommend default view based on most common categories
        category_insights = insights.get('category_insights', {})
        if 'common_categories' in category_insights and category_insights['common_categories']:
            recommendations['default_view'] = category_insights['common_categories'][0]
        
        # Recommend custom categories
        if 'custom_categories' in category_insights:
            recommendations['custom_categories'] = category_insights['custom_categories']
        
        return recommendations
    
    def apply_recommendations(self, recommendations=None):
        """
        Apply recommendations to user preferences.
        
        Args:
            recommendations (dict, optional): Specific recommendations to apply
            
        Returns:
            dict: Updated user preferences
        """
        # If no specific recommendations provided, generate them
        if recommendations is None:
            recommendations = self.get_personalized_recommendations()
            
            # Skip if insufficient data
            if recommendations.get('status') == 'insufficient_data':
                return {
                    'status': 'insufficient_data',
                    'message': recommendations.get('message'),
                    'preferences': self.user_model['preferences']
                }
        
        # Apply processing recommendations
        processing_recs = recommendations.get('processing_recommendations', {})
        if 'optimal_processing_times' in processing_recs:
            self.user_model['preferences']['email_processing']['preferred_times'] = processing_recs['optimal_processing_times']
        
        if 'batch_processing' in processing_recs:
            self.user_model['preferences']['email_processing']['batch_processing'] = processing_recs['batch_processing']
        
        if 'processing_frequency' in processing_recs:
            self.user_model['preferences']['email_processing']['processing_frequency'] = processing_recs['processing_frequency']
        
        # Apply response recommendations
        response_recs = recommendations.get('response_recommendations', {})
        if 'response_style' in response_recs:
            self.user_model['preferences']['response_preferences']['response_style'] = response_recs['response_style']
        
        if 'response_length' in response_recs:
            self.user_model['preferences']['response_preferences']['response_length'] = response_recs['response_length']
        
        # Apply notification recommendations
        notification_recs = recommendations.get('notification_recommendations', {})
        if 'notification_frequency' in notification_recs:
            self.user_model['preferences']['notification_preferences']['notification_frequency'] = notification_recs['notification_frequency']
        
        if 'quiet_hours' in notification_recs:
            self.user_model['preferences']['notification_preferences']['quiet_hours'] = notification_recs['quiet_hours']
        
        # Apply UI recommendations
        ui_recs = recommendations.get('ui_recommendations', {})
        if 'default_view' in ui_recs:
            self.user_model['preferences']['ui_preferences']['default_view'] = ui_recs['default_view']
        
        # Save updated model
        self._save_user_model()
        
        return {
            'status': 'success',
            'message': 'Recommendations applied successfully',
            'preferences': self.user_model['preferences']
        }
    
    def get_user_preferences(self):
        """
        Get current user preferences.
        
        Returns:
            dict: User preferences
        """
        return self.user_model['preferences']
    
    def update_user_preferences(self, preferences):
        """
        Update user preferences manually.
        
        Args:
            preferences (dict): New preferences
            
        Returns:
            dict: Updated user preferences
        """
        # Update preferences
        for category, values in preferences.items():
            if category in self.user_model['preferences']:
                for key, value in values.items():
                    if key in self.user_model['preferences'][category]:
                        self.user_model['preferences'][category][key] = value
        
        # Save updated model
        self._save_user_model()
        
        return {
            'status': 'success',
            'message': 'Preferences updated successfully',
            'preferences': self.user_model['preferences']
        }
    
    def get_sender_importance(self, sender):
        """
        Get importance score for a sender.
        
        Args:
            sender (str): Email sender
            
        Returns:
            float: Importance score
        """
        # Get sender importance
        sender_importance = self.user_model['learned_patterns']['sender_importance']
        
        # Return score if sender exists
        if sender in sender_importance:
            return sender_importance[sender]['importance_score']
        
        # Default score for unknown senders
        return 0
    
    def get_category_for_sender(self, sender, default_category):
        """
        Get preferred category for a sender.
        
        Args:
            sender (str): Email sender
            default_category (str): Default category
            
        Returns:
            str: Preferred category
        """
        # Get category mapping
        category_mapping = self.user_model['learned_patterns']['category_mapping']
        
        # Check if sender has a preferred category mapping
        for key, category in category_mapping.items():
            if key.startswith(f"{sender}:"):
                return category
        
        # Return default category if no mapping found
        return default_category
    
    def get_optimal_notification_times(self):
        """
        Get optimal times for sending notifications.
        
        Returns:
            list: Optimal notification times
        """
        # Get preferred times from preferences
        preferred_times = self.user_model['preferences']['email_processing']['preferred_times']
        
        # If preferred times exist, use them
        if preferred_times:
            return [f"{hour:02d}:00" for hour in preferred_times]
        
        # Otherwise, get active hours
        active_hours = self.user_model['learned_patterns']['time_patterns']['active_hours']
        
        # Convert to list of (hour, count) tuples
        hour_counts = [(int(hour), count) for hour, count in active_hours.items()]
        
        # Sort by count (most active first)
        hour_counts.sort(key=lambda x: x[1], reverse=True)
        
        # Return top 3 hours
        return [f"{hour:02d}:00" for hour, _ in hour_counts[:3]]
    
    def should_send_notification(self, email, current_time=None):
        """
        Determine if a notification should be sent for an email.
        
        Args:
            email (dict): Email data
            current_time (datetime, optional): Current time
            
        Returns:
            bool: True if notification should be sent, False otherwise
        """
        # Get current time if not provided
        if current_time is None:
            current_time = datetime.datetime.now()
        
        # Get notification preferences
        notification_prefs = self.user_model['preferences']['notification_preferences']
        
        # Check quiet hours
        if notification_prefs['quiet_hours']['enabled']:
            start_time = notification_prefs['quiet_hours']['start']
            end_time = notification_prefs['quiet_hours']['end']
            
            start_hour, start_minute = map(int, start_time.split(':'))
            end_hour, end_minute = map(int, end_time.split(':'))
            
            current_hour = current_time.hour
            current_minute = current_time.minute
            
            # Convert to minutes for easier comparison
            start_minutes = start_hour * 60 + start_minute
            end_minutes = end_hour * 60 + end_minute
            current_minutes = current_hour * 60 + current_minute
            
            # Check if current time is within quiet hours
            if start_minutes < end_minutes:
                # Normal case (e.g., 22:00 to 08:00)
                if start_minutes <= current_minutes < end_minutes:
                    return False
            else:
                # Wrap-around case (e.g., 22:00 to 08:00)
                if current_minutes >= start_minutes or current_minutes < end_minutes:
                    return False
        
        # Check urgent only setting
        if notification_prefs['urgent_only']:
            # Determine if email is urgent
            sender = email.get('sender', '')
            subject = email.get('subject', '')
            body = email.get('body', '')
            
            # Check sender importance
            sender_importance = self.get_sender_importance(sender)
            
            # Check for urgency keywords
            urgency_keywords = ['urgent', 'important', 'critical', 'asap', 'emergency', 'immediately']
            has_urgency_keywords = any(keyword in (subject + ' ' + body).lower() for keyword in urgency_keywords)
            
            # Send notification only if sender is important or email has urgency keywords
            return sender_importance > 3 or has_urgency_keywords
        
        # Check notification frequency
        frequency = notification_prefs['notification_frequency']
        
        if frequency == 'low':
            # Only notify for important emails
            sender = email.get('sender', '')
            sender_importance = self.get_sender_importance(sender)
            return sender_importance > 2
        elif frequency == 'medium':
            # Notify for moderately important emails
            sender = email.get('sender', '')
            sender_importance = self.get_sender_importance(sender)
            return sender_importance > 0
        else:  # high
            # Notify for all emails
            return True
    
    def get_model_data(self):
        """
        Get the entire user model data.
        
        Returns:
            dict: User model data
        """
        return self.user_model
