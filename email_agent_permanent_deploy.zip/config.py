"""
Configuration settings for the Email Management AI Agent.
"""

import os

# Gmail API settings
SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']
API_SERVICE_NAME = 'gmail'
API_VERSION = 'v1'
CLIENT_SECRET_FILE = 'client_secret.json'
APPLICATION_NAME = 'Email Management AI Agent'

# Email retrieval settings
MAX_EMAILS_PER_FETCH = 50
BATCH_SIZE = 10
MAX_RESULTS = 100

# Email categorization settings
PRIORITY_LEVELS = ['high', 'medium', 'low']
PRIORITY_KEYWORDS = {
    'high': ['urgent', 'important', 'asap', 'deadline', 'critical', 'emergency'],
    'medium': ['review', 'update', 'meeting', 'report', 'status'],
    'low': ['newsletter', 'fyi', 'announcement', 'update']
}

CATEGORY_RULES = {
    'important': ['urgent', 'important', 'critical', 'deadline'],
    'work': ['project', 'task', 'meeting', 'report', 'client', 'team'],
    'personal': ['family', 'friend', 'vacation', 'holiday', 'personal'],
    'newsletters': ['newsletter', 'subscription', 'digest', 'weekly', 'monthly'],
    'social': ['invitation', 'event', 'party', 'social', 'network'],
    'promotions': ['offer', 'discount', 'sale', 'promotion', 'deal'],
    'updates': ['update', 'notification', 'alert', 'reminder', 'confirmation']
}

# Email summarization settings
SUMMARY_MAX_LENGTH = 150
SUMMARY_MIN_LENGTH = 50

# Action detection settings
ACTION_KEYWORDS = ['please', 'need', 'required', 'action', 'task', 'todo', 'to-do', 'must', 'should']
CALENDAR_KEYWORDS = ['meeting', 'call', 'appointment', 'schedule', 'calendar', 'event']

# Digest settings
DIGEST_MAX_EMAILS = 10
DIGEST_TIMEFRAME_HOURS = 24

# File paths
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
CREDENTIALS_DIR = os.path.join(DATA_DIR, 'credentials')
CACHE_DIR = os.path.join(DATA_DIR, 'cache')

# Create directories if they don't exist
for directory in [DATA_DIR, CREDENTIALS_DIR, CACHE_DIR]:
    os.makedirs(directory, exist_ok=True)

# Demo mode settings
DEMO_MODE = True
