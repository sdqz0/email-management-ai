"""
Workload Management System for Email Management AI Agent.
Helps users prioritize tasks and manage their workload effectively.
"""

import re
import datetime
from dateutil import parser
from dateutil.relativedelta import relativedelta
import heapq
from collections import defaultdict

class WorkloadManager:
    """
    Handles task extraction, prioritization, and workload management.
    """
    
    def __init__(self):
        """
        Initialize the workload manager.
        """
        # Task priority levels
        self.priority_levels = {
            'critical': 5,  # Highest priority
            'high': 4,
            'medium': 3,
            'low': 2,
            'optional': 1   # Lowest priority
        }
        
        # Sender importance levels (to be populated from user data)
        self.sender_importance = {}
        
        # Task extraction patterns
        self.task_patterns = [
            # Direct requests
            r'(?:please|kindly|could you|can you)\s+(.*?)[\.;,]',
            r'(?:need|want|require)\s+you\s+to\s+(.*?)[\.;,]',
            r'(?:would|should)\s+(?:like|appreciate)\s+(?:it\s+)?if\s+you\s+(?:could|would)\s+(.*?)[\.;,]',
            
            # Assignments
            r'(?:assign|assigning|assigned)\s+(?:to\s+)?you\s+(.*?)[\.;,]',
            r'your\s+(?:task|assignment|responsibility)\s+is\s+to\s+(.*?)[\.;,]',
            
            # Action items
            r'action\s+item(?:s)?(?:\s+for\s+you)?:\s+(.*?)[\.;,]',
            r'follow(?:\s+|\-)up(?:\s+item)?(?:s)?:\s+(.*?)[\.;,]',
            
            # Deadlines with tasks
            r'(?:due|complete|finish|submit|deliver)\s+by\s+.*?:\s+(.*?)[\.;,]',
            
            # Implicit tasks
            r'(?:waiting|depend)(?:ing)?\s+on\s+you\s+(?:to|for)\s+(.*?)[\.;,]',
            r'(?:expecting|expect)\s+you\s+to\s+(.*?)[\.;,]'
        ]
        
        # Deadline extraction patterns
        self.deadline_patterns = [
            # Explicit deadlines
            r'(?:due|deadline|complete|finish|submit|deliver)\s+by\s+(.*?)[\.;,]',
            r'(?:due|deadline|completion)\s+date(?:\s+is)?:\s+(.*?)[\.;,]',
            r'(?:needed|required)\s+by\s+(.*?)[\.;,]',
            
            # Timeframe deadlines
            r'within\s+(\d+)\s+(?:day|days|week|weeks|month|months)',
            r'in\s+the\s+next\s+(\d+)\s+(?:day|days|week|weeks|month|months)',
            r'by\s+(?:the\s+)?end\s+of\s+(today|tomorrow|this\s+week|next\s+week|this\s+month)',
            
            # Specific dates
            r'by\s+(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2}(?:st|nd|rd|th)?(?:,?\s+\d{4})?',
            r'by\s+(\d{1,2}(?:st|nd|rd|th)?\s+(?:of\s+)?(?:January|February|March|April|May|June|July|August|September|October|November|December)(?:,?\s+\d{4})?)',
            
            # Relative dates
            r'by\s+(tomorrow|next\s+(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday))',
            r'by\s+(this|next)\s+(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)'
        ]
        
        # Urgency indicators
        self.urgency_indicators = {
            'critical': [
                'urgent', 'critical', 'emergency', 'asap', 'immediately', 'right away',
                'highest priority', 'top priority', 'crisis', 'crucial', 'vital'
            ],
            'high': [
                'important', 'priority', 'as soon as possible', 'timely', 'pressing',
                'significant', 'key', 'major', 'essential', 'necessary'
            ],
            'medium': [
                'needed', 'required', 'should', 'would be good', 'appreciate',
                'helpful', 'beneficial', 'valuable', 'useful'
            ],
            'low': [
                'when you can', 'at your convenience', 'if you have time', 'optional',
                'nice to have', 'would be nice', 'not urgent', 'low priority'
            ]
        }
        
        # Project keywords (to be populated from user data)
        self.project_keywords = {}
        
        # Task status tracking
        self.tasks = {}
        
        # Workload metrics
        self.daily_capacity = 8  # Default: 8 hours per day
        self.task_time_estimates = {
            'critical': 2.0,  # Default: 2 hours for critical tasks
            'high': 1.5,      # Default: 1.5 hours for high priority tasks
            'medium': 1.0,    # Default: 1 hour for medium priority tasks
            'low': 0.5,       # Default: 30 minutes for low priority tasks
            'optional': 0.25  # Default: 15 minutes for optional tasks
        }
    
    def extract_tasks_from_email(self, email):
        """
        Extract tasks from an email.
        
        Args:
            email (dict): Email data
            
        Returns:
            list: List of extracted tasks
        """
        # Get email content
        subject = email.get('subject', '')
        body = email.get('body', '')
        sender = email.get('sender', '')
        date = email.get('date', '')
        email_id = email.get('id', '')
        
        # Combine subject and body for analysis
        text = f"{subject}\n{body}"
        
        # Extract tasks
        tasks = []
        for pattern in self.task_patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                task_description = match.group(1).strip()
                if task_description:
                    # Extract deadline for this specific task
                    deadline = self._extract_deadline_for_task(text, task_description)
                    
                    # Determine priority
                    priority = self._determine_task_priority(text, task_description, sender)
                    
                    # Create task object
                    task = {
                        'id': f"task_{email_id}_{len(tasks)}",
                        'description': task_description,
                        'source_email_id': email_id,
                        'sender': sender,
                        'date_received': date,
                        'deadline': deadline,
                        'priority': priority,
                        'status': 'pending',
                        'estimated_time': self.task_time_estimates.get(priority, 1.0),
                        'project': self._determine_project(text, task_description),
                        'dependencies': self._extract_dependencies(text, task_description)
                    }
                    
                    tasks.append(task)
        
        # If no tasks found but email seems to contain a request, extract a generic task
        if not tasks and self._contains_request(text):
            # Create a generic task based on the email subject
            task = {
                'id': f"task_{email_id}_0",
                'description': f"Review and respond to email: {subject}",
                'source_email_id': email_id,
                'sender': sender,
                'date_received': date,
                'deadline': self._extract_deadline(text),
                'priority': self._determine_task_priority(text, subject, sender),
                'status': 'pending',
                'estimated_time': 0.5,  # Default: 30 minutes for email review
                'project': self._determine_project(text, subject),
                'dependencies': []
            }
            
            tasks.append(task)
        
        return tasks
    
    def _extract_deadline_for_task(self, text, task_description):
        """
        Extract deadline specifically for a task.
        
        Args:
            text (str): Email text
            task_description (str): Task description
            
        Returns:
            dict: Deadline information
        """
        # First, look for deadlines in the vicinity of the task description
        task_context = self._get_context_around_text(text, task_description, 200)
        deadline_text = self._extract_deadline(task_context)
        
        # If no deadline found in context, check the entire text
        if not deadline_text:
            deadline_text = self._extract_deadline(text)
        
        # If still no deadline, return None
        if not deadline_text:
            return None
        
        # Parse the deadline text into a structured format
        return self._parse_deadline(deadline_text)
    
    def _get_context_around_text(self, text, target, context_size=200):
        """
        Get text context around a target string.
        
        Args:
            text (str): Full text
            target (str): Target string to find
            context_size (int): Number of characters to include before and after
            
        Returns:
            str: Context text
        """
        index = text.lower().find(target.lower())
        if index == -1:
            return ""
        
        start = max(0, index - context_size)
        end = min(len(text), index + len(target) + context_size)
        
        return text[start:end]
    
    def _extract_deadline(self, text):
        """
        Extract deadline information from text.
        
        Args:
            text (str): Text to analyze
            
        Returns:
            str: Extracted deadline text or None
        """
        for pattern in self.deadline_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(1).strip()
        
        return None
    
    def _parse_deadline(self, deadline_text):
        """
        Parse deadline text into structured format.
        
        Args:
            deadline_text (str): Deadline text
            
        Returns:
            dict: Structured deadline information
        """
        try:
            # Handle relative terms
            now = datetime.datetime.now()
            
            if re.search(r'\b(today)\b', deadline_text, re.IGNORECASE):
                deadline_date = now.date()
                deadline_time = datetime.time(17, 0)  # Default: 5:00 PM
                
            elif re.search(r'\b(tomorrow)\b', deadline_text, re.IGNORECASE):
                tomorrow = now + datetime.timedelta(days=1)
                deadline_date = tomorrow.date()
                deadline_time = datetime.time(17, 0)  # Default: 5:00 PM
                
            elif re.search(r'\b(this\s+week)\b', deadline_text, re.IGNORECASE):
                # End of this week (Friday)
                days_until_friday = (4 - now.weekday()) % 7
                if days_until_friday == 0:
                    days_until_friday = 7
                friday = now + datetime.timedelta(days=days_until_friday)
                deadline_date = friday.date()
                deadline_time = datetime.time(17, 0)  # Default: 5:00 PM
                
            elif re.search(r'\b(next\s+week)\b', deadline_text, re.IGNORECASE):
                # Middle of next week (Wednesday)
                days_until_next_wednesday = (9 - now.weekday()) % 7
                next_wednesday = now + datetime.timedelta(days=days_until_next_wednesday)
                deadline_date = next_wednesday.date()
                deadline_time = datetime.time(17, 0)  # Default: 5:00 PM
                
            elif re.search(r'\b(this\s+month)\b', deadline_text, re.IGNORECASE):
                # End of this month
                if now.month == 12:
                    deadline_date = datetime.date(now.year, 12, 31)
                else:
                    deadline_date = datetime.date(now.year, now.month + 1, 1) - datetime.timedelta(days=1)
                deadline_time = datetime.time(17, 0)  # Default: 5:00 PM
                
            elif re.search(r'\bwithin\s+(\d+)\s+(day|days|week|weeks|month|months)\b', deadline_text, re.IGNORECASE):
                # Within X days/weeks/months
                match = re.search(r'\bwithin\s+(\d+)\s+(day|days|week|weeks|month|months)\b', deadline_text, re.IGNORECASE)
                amount = int(match.group(1))
                unit = match.group(2).lower()
                
                if unit in ['day', 'days']:
                    deadline_date = (now + datetime.timedelta(days=amount)).date()
                elif unit in ['week', 'weeks']:
                    deadline_date = (now + datetime.timedelta(days=amount * 7)).date()
                elif unit in ['month', 'months']:
                    deadline_date = (now + relativedelta(months=amount)).date()
                
                deadline_time = datetime.time(17, 0)  # Default: 5:00 PM
                
            elif re.search(r'\bnext\s+(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\b', deadline_text, re.IGNORECASE):
                # Next specific day of week
                match = re.search(r'\bnext\s+(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\b', deadline_text, re.IGNORECASE)
                day_name = match.group(1).lower()
                day_map = {'monday': 0, 'tuesday': 1, 'wednesday': 2, 'thursday': 3, 'friday': 4, 'saturday': 5, 'sunday': 6}
                target_day = day_map.get(day_name, 0)
                
                days_until_day = (target_day - now.weekday()) % 7
                if days_until_day == 0:
                    days_until_day = 7
                
                next_day = now + datetime.timedelta(days=days_until_day)
                deadline_date = next_day.date()
                deadline_time = datetime.time(17, 0)  # Default: 5:00 PM
                
            else:
                # Try to parse as a date
                try:
                    parsed_date = parser.parse(deadline_text, fuzzy=True)
                    deadline_date = parsed_date.date()
                    deadline_time = parsed_date.time() if parsed_date.time() != datetime.time(0, 0) else datetime.time(17, 0)
                except:
                    # If parsing fails, default to one week from now
                    next_week = now + datetime.timedelta(days=7)
                    deadline_date = next_week.date()
                    deadline_time = datetime.time(17, 0)  # Default: 5:00 PM
            
            # Create deadline object
            deadline = {
                'date': deadline_date.strftime('%Y-%m-%d'),
                'time': deadline_time.strftime('%H:%M'),
                'datetime': datetime.datetime.combine(deadline_date, deadline_time),
                'original_text': deadline_text
            }
            
            return deadline
            
        except Exception as e:
            # If any error occurs, return a default deadline (one week from now)
            next_week = datetime.datetime.now() + datetime.timedelta(days=7)
            return {
                'date': next_week.date().strftime('%Y-%m-%d'),
                'time': '17:00',
                'datetime': datetime.datetime.combine(next_week.date(), datetime.time(17, 0)),
                'original_text': deadline_text
            }
    
    def _determine_task_priority(self, text, task_description, sender):
        """
        Determine priority of a task.
        
        Args:
            text (str): Email text
            task_description (str): Task description
            sender (str): Email sender
            
        Returns:
            str: Priority level
        """
        # Get context around the task description
        task_context = self._get_context_around_text(text, task_description, 200)
        
        # Check for urgency indicators
        for priority, indicators in self.urgency_indicators.items():
            for indicator in indicators:
                if re.search(r'\b' + re.escape(indicator) + r'\b', task_context, re.IGNORECASE):
                    return priority
        
        # Consider sender importance
        sender_priority = self.sender_importance.get(sender, 'medium')
        
        # Check for deadline proximity
        deadline = self._extract_deadline_for_task(text, task_description)
        if deadline:
            deadline_priority = self._get_priority_from_deadline(deadline)
            
            # Combine sender importance and deadline proximity
            # Return the higher priority of the two
            priority_values = {
                'critical': 5,
                'high': 4,
                'medium': 3,
                'low': 2,
                'optional': 1
            }
            
            if priority_values.get(deadline_priority, 3) > priority_values.get(sender_priority, 3):
                return deadline_priority
            else:
                return sender_priority
        
        # Default to sender priority if no other indicators
        return sender_priority
    
    def _get_priority_from_deadline(self, deadline):
        """
        Determine priority based on deadline proximity.
        
        Args:
            deadline (dict): Deadline information
            
        Returns:
            str: Priority level
        """
        if not deadline or not deadline.get('datetime'):
            return 'medium'
        
        now = datetime.datetime.now()
        deadline_datetime = deadline.get('datetime')
        
        # Calculate time difference
        time_diff = deadline_datetime - now
        
        # Determine priority based on time difference
        if time_diff.total_seconds() < 0:
            # Past deadline
            return 'critical'
        elif time_diff.total_seconds() < 86400:
            # Less than 1 day
            return 'critical'
        elif time_diff.total_seconds() < 172800:
            # Less than 2 days
            return 'high'
        elif time_diff.total_seconds() < 604800:
            # Less than 1 week
            return 'medium'
        else:
            # More than 1 week
            return 'low'
    
    def _determine_project(self, text, task_description):
        """
        Determine project associated with a task.
        
        Args:
            text (str): Email text
            task_description (str): Task description
            
        Returns:
            str: Project name or None
        """
        # Check for project keywords in the text
        for project, keywords in self.project_keywords.items():
            for keyword in keywords:
                if re.search(r'\b' + re.escape(keyword) + r'\b', text, re.IGNORECASE):
                    return project
        
        # If no project found, return None
        return None
    
    def _extract_dependencies(self, text, task_description):
        """
        Extract task dependencies.
        
        Args:
            text (str): Email text
            task_description (str): Task description
            
        Returns:
            list: List of dependency descriptions
        """
        # Look for dependency indicators
        dependency_patterns = [
            r'(?:after|once|when)\s+(?:you|we)\s+(?:have|get|receive|complete|finish)\s+(.*?)[\.;,]',
            r'(?:depends|dependent)\s+on\s+(.*?)[\.;,]',
            r'(?:requires|requiring|need)\s+(.*?)\s+(?:first|beforehand|before)[\.;,]',
            r'(?:following|after)\s+(.*?)[\.;,]'
        ]
        
        dependencies = []
        for pattern in dependency_patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                dependency = match.group(1).strip()
                if dependency and dependency not in dependencies:
                    dependencies.append(dependency)
        
        return dependencies
    
    def _contains_request(self, text):
        """
        Check if text contains a request.
        
        Args:
            text (str): Text to analyze
            
        Returns:
            bool: True if text contains a request, False otherwise
        """
        request_indicators = [
            r'\b(?:please|kindly|could you|can you|would you|should you)\b',
            r'\b(?:need|want|require)\s+you\s+to\b',
            r'\b(?:would|should)\s+(?:like|appreciate)\s+(?:it\s+)?if\s+you\b',
            r'\b(?:assign|assigning|assigned)\s+(?:to\s+)?you\b',
            r'\byour\s+(?:task|assignment|responsibility)\b',
            r'\baction\s+item(?:s)?\b',
            r'\bfollow(?:\s+|\-)up(?:\s+item)?(?:s)?\b'
        ]
        
        for pattern in request_indicators:
            if re.search(pattern, text, re.IGNORECASE):
                return True
        
        return False
    
    def prioritize_tasks(self, tasks, user_calendar=None):
        """
        Prioritize tasks based on multiple factors.
        
        Args:
            tasks (list): List of tasks
            user_calendar (dict, optional): User calendar data
            
        Returns:
            list: Prioritized list of tasks
        """
        # Create a priority queue
        priority_queue = []
        
        for task in tasks:
            # Calculate priority score
            score = self._calculate_priority_score(task)
            
            # Add to priority queue (negative score for max-heap behavior)
            heapq.heappush(priority_queue, (-score, task))
        
        # Extract tasks in priority order
        prioritized_tasks = []
        while priority_queue:
            score, task = heapq.heappop(priority_queue)
            task['priority_score'] = -score  # Store the actual score
            prioritized_tasks.append(task)
        
        return prioritized_tasks
    
    def _calculate_priority_score(self, task):
        """
        Calculate priority score for a task.
        
        Args:
            task (dict): Task data
            
        Returns:
            float: Priority score
        """
        score = 0
        
        # Base score from priority level
        priority_level = task.get('priority', 'medium')
        score += self.priority_levels.get(priority_level, 3) * 10
        
        # Deadline factor
        deadline = task.get('deadline')
        if deadline and deadline.get('datetime'):
            now = datetime.datetime.now()
            deadline_datetime = deadline.get('datetime')
            
            # Calculate time difference in hours
            time_diff = (deadline_datetime - now).total_seconds() / 3600
            
            if time_diff < 0:
                # Past deadline
                score += 50
            elif time_diff < 24:
                # Due within 24 hours
                score += 40
            elif time_diff < 48:
                # Due within 48 hours
                score += 30
            elif time_diff < 168:
                # Due within a week
                score += 20
            else:
                # Due later
                score += 10
        
        # Sender importance factor
        sender = task.get('sender', '')
        sender_importance_value = self.priority_levels.get(
            self.sender_importance.get(sender, 'medium'),
            3
        )
        score += sender_importance_value * 5
        
        # Age factor (older tasks get higher priority)
        date_received = task.get('date_received')
        if date_received:
            try:
                received_date = parser.parse(date_received)
                age_days = (datetime.datetime.now() - received_date).days
                score += min(age_days * 2, 20)  # Cap at 20 points (10 days old)
            except:
                pass
        
        # Project factor (if applicable)
        if task.get('project'):
            score += 5
        
        # Dependency factor (fewer dependencies get higher priority)
        dependencies = task.get('dependencies', [])
        score -= len(dependencies) * 3
        
        # Estimated time factor (quicker tasks get slight priority)
        estimated_time = task.get('estimated_time', 1.0)
        if estimated_time <= 0.5:  # 30 minutes or less
            score += 3
        elif estimated_time <= 1.0:  # 1 hour or less
            score += 2
        
        return score
    
    def schedule_tasks(self, prioritized_tasks, user_calendar=None):
        """
        Schedule tasks based on priority and calendar availability.
        
        Args:
            prioritized_tasks (list): Prioritized list of tasks
            user_calendar (dict, optional): User calendar data
            
        Returns:
            dict: Scheduled tasks by day
        """
        # Initialize schedule
        schedule = defaultdict(list)
        
        # Get available time slots
        available_slots = self._get_available_time_slots(user_calendar)
        
        # Assign tasks to time slots
        for task in prioritized_tasks:
            # Skip completed tasks
            if task.get('status') == 'completed':
                continue
            
            # Get estimated time for task
            estimated_hours = task.get('estimated_time', 1.0)
            
            # Find suitable time slot
            assigned = False
            
            # First try to schedule before deadline if one exists
            deadline = task.get('deadline')
            if deadline and deadline.get('datetime'):
                deadline_date = deadline.get('date')
                
                # Try to schedule on days before the deadline
                for date, slots in available_slots.items():
                    if date <= deadline_date:
                        for slot in slots:
                            if slot['available_hours'] >= estimated_hours:
                                # Assign task to this slot
                                schedule[date].append({
                                    'task': task,
                                    'start_time': slot['start_time'],
                                    'end_time': self._add_hours_to_time(slot['start_time'], estimated_hours)
                                })
                                
                                # Update available hours in slot
                                slot['available_hours'] -= estimated_hours
                                slot['start_time'] = self._add_hours_to_time(slot['start_time'], estimated_hours)
                                
                                assigned = True
                                break
                    
                    if assigned:
                        break
            
            # If not assigned yet, schedule on any available day
            if not assigned:
                for date, slots in available_slots.items():
                    for slot in slots:
                        if slot['available_hours'] >= estimated_hours:
                            # Assign task to this slot
                            schedule[date].append({
                                'task': task,
                                'start_time': slot['start_time'],
                                'end_time': self._add_hours_to_time(slot['start_time'], estimated_hours)
                            })
                            
                            # Update available hours in slot
                            slot['available_hours'] -= estimated_hours
                            slot['start_time'] = self._add_hours_to_time(slot['start_time'], estimated_hours)
                            
                            assigned = True
                            break
                    
                    if assigned:
                        break
            
            # If still not assigned, add to overflow
            if not assigned:
                schedule['overflow'].append({
                    'task': task,
                    'start_time': None,
                    'end_time': None
                })
        
        return schedule
    
    def _get_available_time_slots(self, user_calendar=None):
        """
        Get available time slots for scheduling.
        
        Args:
            user_calendar (dict, optional): User calendar data
            
        Returns:
            dict: Available time slots by day
        """
        # Initialize available slots
        available_slots = defaultdict(list)
        
        # Get current date
        now = datetime.datetime.now()
        
        # Generate slots for the next 7 days
        for i in range(7):
            date = (now + datetime.timedelta(days=i)).date()
            date_str = date.strftime('%Y-%m-%d')
            
            # Default work hours: 9 AM to 5 PM
            if user_calendar and date_str in user_calendar:
                # Use calendar data if available
                calendar_events = user_calendar[date_str]
                available_slots[date_str] = self._calculate_available_slots(date, calendar_events)
            else:
                # Default: one slot for the whole workday
                available_slots[date_str] = [{
                    'start_time': '09:00',
                    'end_time': '17:00',
                    'available_hours': 8.0
                }]
        
        return available_slots
    
    def _calculate_available_slots(self, date, calendar_events):
        """
        Calculate available time slots based on calendar events.
        
        Args:
            date (datetime.date): Date to calculate slots for
            calendar_events (list): List of calendar events
            
        Returns:
            list: Available time slots
        """
        # Default work hours
        work_start = datetime.time(9, 0)
        work_end = datetime.time(17, 0)
        
        # Convert calendar events to busy times
        busy_times = []
        for event in calendar_events:
            start_time = event.get('start_time')
            end_time = event.get('end_time')
            
            if start_time and end_time:
                busy_times.append({
                    'start': start_time,
                    'end': end_time
                })
        
        # Sort busy times
        busy_times.sort(key=lambda x: x['start'])
        
        # Calculate available slots
        available_slots = []
        current_time = work_start.strftime('%H:%M')
        
        for busy in busy_times:
            busy_start = busy['start']
            busy_end = busy['end']
            
            # If there's time before this busy period, add it as available
            if current_time < busy_start:
                available_hours = self._calculate_hours_between(current_time, busy_start)
                if available_hours >= 0.25:  # Minimum 15 minutes
                    available_slots.append({
                        'start_time': current_time,
                        'end_time': busy_start,
                        'available_hours': available_hours
                    })
            
            # Move current time to after this busy period
            current_time = busy_end
        
        # Add remaining time until end of workday
        work_end_str = work_end.strftime('%H:%M')
        if current_time < work_end_str:
            available_hours = self._calculate_hours_between(current_time, work_end_str)
            if available_hours >= 0.25:  # Minimum 15 minutes
                available_slots.append({
                    'start_time': current_time,
                    'end_time': work_end_str,
                    'available_hours': available_hours
                })
        
        return available_slots
    
    def _calculate_hours_between(self, start_time, end_time):
        """
        Calculate hours between two time strings.
        
        Args:
            start_time (str): Start time in format 'HH:MM'
            end_time (str): End time in format 'HH:MM'
            
        Returns:
            float: Hours between times
        """
        start_hour, start_minute = map(int, start_time.split(':'))
        end_hour, end_minute = map(int, end_time.split(':'))
        
        start_minutes = start_hour * 60 + start_minute
        end_minutes = end_hour * 60 + end_minute
        
        return (end_minutes - start_minutes) / 60.0
    
    def _add_hours_to_time(self, time_str, hours):
        """
        Add hours to a time string.
        
        Args:
            time_str (str): Time in format 'HH:MM'
            hours (float): Hours to add
            
        Returns:
            str: New time in format 'HH:MM'
        """
        hour, minute = map(int, time_str.split(':'))
        
        # Convert hours to minutes
        minutes_to_add = int(hours * 60)
        
        # Add minutes
        total_minutes = hour * 60 + minute + minutes_to_add
        
        # Convert back to hours and minutes
        new_hour = (total_minutes // 60) % 24
        new_minute = total_minutes % 60
        
        return f"{new_hour:02d}:{new_minute:02d}"
    
    def update_task_status(self, task_id, new_status):
        """
        Update the status of a task.
        
        Args:
            task_id (str): Task ID
            new_status (str): New status
            
        Returns:
            bool: Success indicator
        """
        if task_id in self.tasks:
            self.tasks[task_id]['status'] = new_status
            return True
        
        return False
    
    def get_workload_metrics(self, tasks):
        """
        Calculate workload metrics.
        
        Args:
            tasks (list): List of tasks
            
        Returns:
            dict: Workload metrics
        """
        # Initialize metrics
        metrics = {
            'total_tasks': len(tasks),
            'completed_tasks': 0,
            'pending_tasks': 0,
            'overdue_tasks': 0,
            'critical_tasks': 0,
            'high_priority_tasks': 0,
            'estimated_hours': 0,
            'workload_by_day': defaultdict(float),
            'workload_by_project': defaultdict(float)
        }
        
        # Current date and time
        now = datetime.datetime.now()
        
        # Calculate metrics
        for task in tasks:
            # Task counts by status
            status = task.get('status', 'pending')
            if status == 'completed':
                metrics['completed_tasks'] += 1
            else:
                metrics['pending_tasks'] += 1
                
                # Check if overdue
                deadline = task.get('deadline')
                if deadline and deadline.get('datetime'):
                    if deadline['datetime'] < now:
                        metrics['overdue_tasks'] += 1
            
            # Task counts by priority
            priority = task.get('priority', 'medium')
            if priority == 'critical':
                metrics['critical_tasks'] += 1
            elif priority == 'high':
                metrics['high_priority_tasks'] += 1
            
            # Estimated hours
            if status != 'completed':
                estimated_time = task.get('estimated_time', 1.0)
                metrics['estimated_hours'] += estimated_time
                
                # Workload by day
                if deadline and deadline.get('date'):
                    metrics['workload_by_day'][deadline['date']] += estimated_time
                
                # Workload by project
                project = task.get('project', 'Unassigned')
                metrics['workload_by_project'][project] += estimated_time
        
        # Calculate workload balance
        daily_capacity = self.daily_capacity
        workload_balance = {}
        
        for day, hours in metrics['workload_by_day'].items():
            workload_balance[day] = {
                'hours': hours,
                'capacity': daily_capacity,
                'percentage': (hours / daily_capacity) * 100 if daily_capacity > 0 else 0,
                'overloaded': hours > daily_capacity
            }
        
        metrics['workload_balance'] = workload_balance
        
        # Convert defaultdicts to regular dicts for serialization
        metrics['workload_by_day'] = dict(metrics['workload_by_day'])
        metrics['workload_by_project'] = dict(metrics['workload_by_project'])
        
        return metrics
    
    def get_task_recommendations(self, tasks, user_calendar=None):
        """
        Generate task recommendations.
        
        Args:
            tasks (list): List of tasks
            user_calendar (dict, optional): User calendar data
            
        Returns:
            dict: Task recommendations
        """
        # Prioritize tasks
        prioritized_tasks = self.prioritize_tasks(tasks, user_calendar)
        
        # Schedule tasks
        schedule = self.schedule_tasks(prioritized_tasks, user_calendar)
        
        # Calculate workload metrics
        metrics = self.get_workload_metrics(tasks)
        
        # Generate recommendations
        recommendations = {
            'focus_tasks': [],
            'schedule': schedule,
            'metrics': metrics,
            'suggestions': []
        }
        
        # Identify top 3 focus tasks
        focus_count = 0
        for task in prioritized_tasks:
            if task.get('status') != 'completed' and focus_count < 3:
                recommendations['focus_tasks'].append(task)
                focus_count += 1
        
        # Generate workload suggestions
        if metrics['estimated_hours'] > self.daily_capacity * 5:
            recommendations['suggestions'].append({
                'type': 'workload',
                'message': 'Your workload exceeds capacity for the week. Consider delegating or renegotiating deadlines.'
            })
        
        # Generate deadline suggestions
        if metrics['overdue_tasks'] > 0:
            recommendations['suggestions'].append({
                'type': 'deadline',
                'message': f"You have {metrics['overdue_tasks']} overdue tasks. Consider addressing these immediately."
            })
        
        # Generate priority suggestions
        if metrics['critical_tasks'] + metrics['high_priority_tasks'] > 5:
            recommendations['suggestions'].append({
                'type': 'priority',
                'message': 'You have many high-priority tasks. Focus on the most critical ones first.'
            })
        
        # Generate daily balance suggestions
        overloaded_days = [day for day, data in metrics['workload_balance'].items() if data['overloaded']]
        if overloaded_days:
            recommendations['suggestions'].append({
                'type': 'balance',
                'message': f"Your workload is unbalanced. Consider redistributing tasks from {', '.join(overloaded_days)}."
            })
        
        return recommendations
    
    def update_user_preferences(self, preferences):
        """
        Update user preferences for workload management.
        
        Args:
            preferences (dict): User preferences
            
        Returns:
            bool: Success indicator
        """
        # Update daily capacity
        if 'daily_capacity' in preferences:
            self.daily_capacity = float(preferences['daily_capacity'])
        
        # Update task time estimates
        if 'task_time_estimates' in preferences:
            self.task_time_estimates.update(preferences['task_time_estimates'])
        
        # Update sender importance
        if 'sender_importance' in preferences:
            self.sender_importance.update(preferences['sender_importance'])
        
        # Update project keywords
        if 'project_keywords' in preferences:
            self.project_keywords.update(preferences['project_keywords'])
        
        return True
    
    def learn_from_user_behavior(self, user_actions):
        """
        Learn from user behavior to improve workload management.
        
        Args:
            user_actions (list): List of user actions
            
        Returns:
            bool: Success indicator
        """
        # This is a placeholder for a more sophisticated learning mechanism
        # In a real implementation, this would update the model based on user behavior
        
        # For now, we'll just return True to indicate success
        return True
